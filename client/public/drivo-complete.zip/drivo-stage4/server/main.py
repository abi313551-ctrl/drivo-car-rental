import os
import random
import uuid
import time
from pathlib import Path
from contextlib import asynccontextmanager
from datetime import datetime
from typing import Optional
from fastapi import FastAPI, Depends, HTTPException, Query, status, File, UploadFile
from fastapi.staticfiles import StaticFiles
from fastapi.middleware.cors import CORSMiddleware
from sqlalchemy.orm import Session

from database import Base, engine, SessionLocal, get_db, ACTIVE_DB_BACKEND
from models import User, Car, Favorite, Coupon, Booking, ContactMessage, Review, Notification
from auth import (
    hash_password,
    verify_password,
    create_access_token,
    get_current_user,
    get_optional_user,
    get_admin_user,
)
from schemas import (
    RegisterRequest,
    LoginRequest,
    ProfileUpdateRequest,
    BookingCreateRequest,
    PaymentUpdateRequest,
    CarCreateUpdateRequest,
    ContactCreateRequest,
    CouponValidateRequest,
    BookingStatusUpdateRequest,
    ReviewCreateRequest,
    parse_iso_dt,
    validate_date_range,
    calculate_server_pricing,
)
from seed import seed_initial_data, BASE_FEATURES, EXTRA_FEATURES

BASE_DIR = Path(__file__).resolve().parent
UPLOADS_ROOT = BASE_DIR / "uploads"
CAR_UPLOADS_DIR = UPLOADS_ROOT / "cars"
CAR_UPLOADS_DIR.mkdir(parents=True, exist_ok=True)

ALLOWED_IMAGE_EXTENSIONS = {".jpg", ".jpeg", ".png", ".webp"}
ALLOWED_IMAGE_MIMES = {"image/jpeg", "image/png", "image/webp", "image/pjpeg"}
MAX_IMAGE_SIZE_BYTES = 5 * 1024 * 1024  # 5 MB


def on_startup():
    Base.metadata.create_all(bind=engine)
    db = SessionLocal()
    try:
        seed_initial_data(db)
    finally:
        db.close()


@asynccontextmanager
async def lifespan(app: FastAPI):
    on_startup()
    yield


app = FastAPI(title="Drivo Car Rental API", version="1.0.0", lifespan=lifespan)

app.mount("/uploads", StaticFiles(directory=str(UPLOADS_ROOT)), name="uploads")

app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)

ACTIVE_STATUSES = {"Pending", "Confirmed"}
CHARS = "ABCDEFGHJKLMNPQRSTUVWXYZ23456789"


def serialize_user(u: User) -> dict:
    return {
        "id": u.id,
        "fullName": u.full_name,
        "email": u.email,
        "phone": u.phone or "",
        "license": u.license_number or "",
        "role": u.role,
        "createdAt": u.created_at.isoformat() if u.created_at else None,
    }


def _ensure_list(val, fallback):
    if isinstance(val, list):
        return val
    if isinstance(val, str):
        try:
            import json
            parsed = json.loads(val)
            if isinstance(parsed, list):
                return parsed
        except Exception:
            pass
    return fallback


def serialize_car(c: Car) -> dict:
    fallback_imgs = [c.image] if c.image else []
    images = _ensure_list(c.images, fallback_imgs)
    features = _ensure_list(c.features, [])
    return {
        "id": c.id,
        "brand": c.brand,
        "model": c.model,
        "year": c.year,
        "category": c.category,
        "fuel": c.fuel,
        "transmission": c.transmission,
        "seats": c.seats,
        "pricePerDay": c.price_per_day,
        "rating": c.rating,
        "location": c.location,
        "popularity": c.popularity,
        "image": c.image,
        "images": images if images else fallback_imgs,
        "deposit": c.deposit,
        "available": bool(c.available),
        "features": features,
        "description": c.description,
    }


def serialize_booking(b: Booking) -> dict:
    car = b.car
    car_snapshot = {
        "id": b.car_id,
        "brand": car.brand if car else "Car",
        "model": car.model if car else "",
        "year": car.year if car else 2024,
        "image": car.image if car else "",
        "category": car.category if car else "",
        "pricePerDay": car.price_per_day if car else 0,
        "location": car.location if car else "",
    }
    return {
        "id": b.id,
        "ref": b.ref,
        "userId": b.user_id,
        "carId": b.car_id,
        "car": car_snapshot,
        "pickup": b.pickup,
        "dropoff": b.dropoff,
        "start": b.start_time,
        "end": b.end_time,
        "customer": b.customer,
        "extras": b.extras,
        "pricing": b.pricing,
        "status": b.status,
        "paymentStatus": b.payment_status,
        "paymentMethod": b.payment_method,
        "createdAt": b.created_at.isoformat() if b.created_at else None,
        "cancelledAt": b.cancelled_at.isoformat() if b.cancelled_at else None,
    }


def serialize_review(r: Review) -> dict:
    return {
        "id": r.id,
        "carId": r.car_id,
        "bookingId": r.booking_id,
        "userId": r.user_id,
        "userName": r.user.full_name if r.user else "Verified Customer",
        "rating": r.rating,
        "title": r.title or "",
        "comment": r.comment,
        "createdAt": r.created_at.isoformat() if r.created_at else None,
        "isVerified": True,
    }


def serialize_notification(n: Notification) -> dict:
    return {
        "id": n.id,
        "userId": n.user_id,
        "title": n.title,
        "message": n.message,
        "type": n.type,
        "read": bool(n.read),
        "createdAt": n.created_at.isoformat() if n.created_at else None,
    }



def find_car_conflict(db: Session, car_id: int, start_str: str, end_str: str, ignore_ref: Optional[str] = None) -> Optional[Booking]:
    s_dt = parse_iso_dt(start_str)
    e_dt = parse_iso_dt(end_str)
    bookings = db.query(Booking).filter(Booking.car_id == car_id, Booking.status.in_(ACTIVE_STATUSES)).all()
    for b in bookings:
        if ignore_ref and b.ref == ignore_ref:
            continue
        try:
            bs = parse_iso_dt(b.start_time)
            be = parse_iso_dt(b.end_time)
            if s_dt < be and bs < e_dt:
                return b
        except Exception:
            continue
    return None


def generate_booking_ref(db: Session) -> str:
    now = datetime.utcnow()
    d = f"{str(now.year)[2:]}{now.month:02d}{now.day:02d}"
    while True:
        suffix = "".join(random.choice(CHARS) for _ in range(5))
        ref = f"DRV-{d}-{suffix}"
        if not db.query(Booking).filter(Booking.ref == ref).first():
            return ref


# --- Health ---
@app.get("/api/health")
def health_check():
    return {"status": "ok", "service": "Drivo FastAPI Backend", "database": ACTIVE_DB_BACKEND}


# --- Auth & Users ---
@app.post("/api/auth/register", status_code=status.HTTP_201_CREATED)
def register(payload: RegisterRequest, db: Session = Depends(get_db)):
    email = payload.email.lower().strip()
    if db.query(User).filter(User.email == email).first():
        raise HTTPException(status_code=400, detail="An account with this email already exists.")
    user = User(
        full_name=payload.fullName.strip(),
        email=email,
        phone=(payload.phone or "").strip(),
        license_number=(payload.license or "").strip().upper(),
        password_hash=hash_password(payload.password),
        role="customer",
    )
    db.add(user)
    db.commit()
    db.refresh(user)
    token = create_access_token({"sub": str(user.id), "role": user.role})
    return {"token": token, "user": serialize_user(user)}


@app.post("/api/auth/login")
def login(payload: LoginRequest, db: Session = Depends(get_db)):
    email = payload.email.lower().strip()
    user = db.query(User).filter(User.email == email).first()
    if not user or not verify_password(payload.password, user.password_hash):
        raise HTTPException(status_code=401, detail="Invalid email or password.")
    token = create_access_token({"sub": str(user.id), "role": user.role})
    return {"token": token, "user": serialize_user(user)}


@app.get("/api/auth/me")
def get_me(user: User = Depends(get_current_user)):
    return {"user": serialize_user(user)}


@app.put("/api/auth/me")
def update_me(payload: ProfileUpdateRequest, user: User = Depends(get_current_user), db: Session = Depends(get_db)):
    user.full_name = payload.fullName.strip()
    user.phone = (payload.phone or "").strip()
    user.license_number = (payload.license or "").strip().upper()
    db.commit()
    db.refresh(user)
    return {"user": serialize_user(user)}


# --- Cars ---
@app.get("/api/cars")
def list_cars(db: Session = Depends(get_db)):
    cars = db.query(Car).order_by(Car.id.asc()).all()
    return {"cars": [serialize_car(c) for c in cars]}


@app.get("/api/cars/{car_id}")
def get_car(car_id: int, db: Session = Depends(get_db)):
    car = db.query(Car).filter(Car.id == car_id).first()
    if not car:
        raise HTTPException(status_code=404, detail="Car not found.")
    return {"car": serialize_car(car)}


@app.get("/api/cars/{car_id}/availability")
def check_car_availability(
    car_id: int,
    start: str = Query(...),
    end: str = Query(...),
    db: Session = Depends(get_db),
):
    car = db.query(Car).filter(Car.id == car_id).first()
    if not car:
        raise HTTPException(status_code=404, detail="Car not found.")
    if not car.available:
        return {"available": False, "reason": "Car is currently marked unavailable."}
    try:
        validate_date_range(start, end, check_past=False)
    except ValueError as e:
        raise HTTPException(status_code=400, detail=str(e))

    conflict = find_car_conflict(db, car_id, start, end)
    if conflict:
        return {
            "available": False,
            "conflict": {"start": conflict.start_time, "end": conflict.end_time, "ref": conflict.ref},
        }
    return {"available": True, "conflict": None}


def safe_delete_car_image_file(image_path: Optional[str], db: Session, exclude_car_id: Optional[int] = None):
    if not image_path or not isinstance(image_path, str):
        return
    if not image_path.startswith("/uploads/cars/"):
        return
    filename = Path(image_path).name
    # Prevent directory traversal
    if ".." in filename or "/" in filename or "\\" in filename:
        return
    # Check if another car in the database references this image
    query = db.query(Car).filter(Car.image == image_path)
    if exclude_car_id is not None:
        query = query.filter(Car.id != exclude_car_id)
    if query.first():
        return
    file_on_disk = CAR_UPLOADS_DIR / filename
    try:
        if file_on_disk.is_file():
            file_on_disk.unlink()
    except OSError:
        pass


@app.post("/api/admin/cars/upload-image")
async def upload_car_image(
    file: UploadFile = File(...),
    admin: User = Depends(get_admin_user),
):
    if not file or not file.filename:
        raise HTTPException(status_code=400, detail="No image file was provided.")

    orig_ext = Path(file.filename).suffix.lower()
    if orig_ext not in ALLOWED_IMAGE_EXTENSIONS:
        raise HTTPException(
            status_code=400,
            detail=f"Unsupported file format '{orig_ext}'. Allowed formats: JPG, JPEG, PNG, WEBP.",
        )

    content_type = (file.content_type or "").lower()
    if content_type not in ALLOWED_IMAGE_MIMES:
        raise HTTPException(
            status_code=400,
            detail=f"Invalid file MIME type '{content_type}'. Must be a valid JPG, PNG, or WEBP image.",
        )

    chunk_size = 1024 * 64
    total_bytes = 0
    chunks = []
    while True:
        chunk = await file.read(chunk_size)
        if not chunk:
            break
        total_bytes += len(chunk)
        if total_bytes > MAX_IMAGE_SIZE_BYTES:
            raise HTTPException(
                status_code=400,
                detail=f"File exceeds maximum allowed size of 5 MB (received > 5 MB).",
            )
        chunks.append(chunk)

    if total_bytes == 0:
        raise HTTPException(status_code=400, detail="The uploaded image is empty (0 bytes).")

    unique_name = f"car_{int(time.time())}_{uuid.uuid4().hex[:10]}{orig_ext}"
    dest_path = CAR_UPLOADS_DIR / unique_name

    with open(dest_path, "wb") as f:
        for c in chunks:
            f.write(c)

    relative_url = f"/uploads/cars/{unique_name}"
    return {
        "url": relative_url,
        "filename": unique_name,
        "size": total_bytes,
        "contentType": content_type,
        "message": "Car image uploaded successfully.",
    }


@app.post("/api/cars", status_code=status.HTTP_201_CREATED)
def create_car(payload: CarCreateUpdateRequest, admin: User = Depends(get_admin_user), db: Session = Depends(get_db)):
    imgs = payload.images if payload.images else [payload.image]
    feats = payload.features if payload.features else BASE_FEATURES + EXTRA_FEATURES.get(payload.category, [])
    desc = payload.description or (
        f"The {payload.year} {payload.brand} {payload.model} is a {payload.fuel.lower()} "
        f"{payload.category.lower()} with {payload.transmission.lower()} transmission and room for {payload.seats}."
    )
    car = Car(
        brand=payload.brand.strip(),
        model=payload.model.strip(),
        year=payload.year,
        category=payload.category,
        fuel=payload.fuel,
        transmission=payload.transmission,
        seats=payload.seats,
        price_per_day=payload.pricePerDay,
        rating=4.6,
        location=payload.location,
        popularity=80,
        image=payload.image,
        images=imgs,
        deposit=payload.deposit,
        available=payload.available,
        features=feats,
        description=desc,
    )
    db.add(car)
    db.commit()
    db.refresh(car)
    return {"car": serialize_car(car)}


@app.patch("/api/cars/{car_id}/availability")
def toggle_car_availability(car_id: int, available: bool = Query(...), admin: User = Depends(get_admin_user), db: Session = Depends(get_db)):
    car = db.query(Car).filter(Car.id == car_id).first()
    if not car:
        raise HTTPException(status_code=404, detail="Car not found.")
    car.available = available
    db.commit()
    db.refresh(car)
    return {"car": serialize_car(car)}


@app.put("/api/cars/{car_id}")
def update_car(car_id: int, payload: CarCreateUpdateRequest, admin: User = Depends(get_admin_user), db: Session = Depends(get_db)):
    car = db.query(Car).filter(Car.id == car_id).first()
    if not car:
        raise HTTPException(status_code=404, detail="Car not found.")
    old_image = car.image
    imgs = payload.images if payload.images else [payload.image]
    feats = payload.features if payload.features else car.features
    desc = payload.description or car.description
    car.brand = payload.brand.strip()
    car.model = payload.model.strip()
    car.year = payload.year
    car.category = payload.category
    car.fuel = payload.fuel
    car.transmission = payload.transmission
    car.seats = payload.seats
    car.price_per_day = payload.pricePerDay
    car.deposit = payload.deposit
    car.location = payload.location
    car.image = payload.image
    car.images = imgs
    car.features = feats
    car.description = desc
    car.available = payload.available
    db.commit()
    db.refresh(car)
    if old_image != car.image:
        safe_delete_car_image_file(old_image, db, exclude_car_id=car.id)
    return {"car": serialize_car(car)}


@app.delete("/api/cars/{car_id}")
def delete_car(car_id: int, admin: User = Depends(get_admin_user), db: Session = Depends(get_db)):
    car = db.query(Car).filter(Car.id == car_id).first()
    if not car:
        raise HTTPException(status_code=404, detail="Car not found.")
    active_b = db.query(Booking).filter(Booking.car_id == car_id, Booking.status.in_(ACTIVE_STATUSES)).first()
    if active_b:
        raise HTTPException(status_code=400, detail=f"Cannot delete car with active booking ({active_b.ref}). Mark as unavailable instead.")
    old_image = car.image
    db.delete(car)
    db.commit()
    safe_delete_car_image_file(old_image, db)
    return {"ok": True, "message": f"{car.brand} {car.model} removed from fleet."}



# --- Favorites ---
@app.get("/api/favorites")
def get_favorites(user: User = Depends(get_current_user), db: Session = Depends(get_db)):
    favs = db.query(Favorite).filter(Favorite.user_id == user.id).all()
    return {"favorites": [f.car_id for f in favs]}


@app.post("/api/favorites/{car_id}")
def toggle_favorite(car_id: int, user: User = Depends(get_current_user), db: Session = Depends(get_db)):
    car = db.query(Car).filter(Car.id == car_id).first()
    if not car:
        raise HTTPException(status_code=404, detail="Car not found.")
    existing = db.query(Favorite).filter(Favorite.user_id == user.id, Favorite.car_id == car_id).first()
    if existing:
        db.delete(existing)
        db.commit()
        action = "removed"
    else:
        db.add(Favorite(user_id=user.id, car_id=car_id))
        db.commit()
        action = "added"
    favs = db.query(Favorite).filter(Favorite.user_id == user.id).all()
    return {"action": action, "favorites": [f.car_id for f in favs]}


@app.delete("/api/favorites")
def clear_favorites(user: User = Depends(get_current_user), db: Session = Depends(get_db)):
    db.query(Favorite).filter(Favorite.user_id == user.id).delete()
    db.commit()
    return {"favorites": []}


# --- Coupons & Pricing ---
@app.get("/api/coupons")
def list_coupons(db: Session = Depends(get_db)):
    coupons = db.query(Coupon).all()
    return {
        "coupons": [
            {
                "code": c.code,
                "type": c.type,
                "value": c.value,
                "category": c.category,
                "weekendOnly": c.weekend_only,
                "active": c.active,
                "description": c.description,
            }
            for c in coupons
        ]
    }


# --- Bookings ---
@app.get("/api/bookings")
def list_bookings(user: Optional[User] = Depends(get_optional_user), db: Session = Depends(get_db)):
    # Returns all active booking time slots for conflict detection + full details for the current user or admin
    bookings = db.query(Booking).order_by(Booking.created_at.desc()).all()
    return {"bookings": [serialize_booking(b) for b in bookings]}


@app.get("/api/bookings/{ref}")
def get_booking_by_ref(ref: str, db: Session = Depends(get_db)):
    booking = db.query(Booking).filter(Booking.ref == ref).first()
    if not booking:
        raise HTTPException(status_code=404, detail="Booking not found.")
    return {"booking": serialize_booking(booking)}


@app.post("/api/bookings", status_code=status.HTTP_201_CREATED)
def create_booking(
    payload: BookingCreateRequest,
    user: Optional[User] = Depends(get_optional_user),
    db: Session = Depends(get_db),
):
    car = db.query(Car).filter(Car.id == payload.carId).first()
    if not car:
        raise HTTPException(status_code=404, detail="Selected car does not exist.")
    if not car.available:
        raise HTTPException(status_code=400, detail=f"{car.brand} {car.model} is currently unavailable.")

    try:
        validate_date_range(payload.start, payload.end)
    except ValueError as e:
        raise HTTPException(status_code=400, detail=str(e))

    conflict = find_car_conflict(db, car.id, payload.start, payload.end)
    if conflict:
        raise HTTPException(
            status_code=409,
            detail=f"{car.brand} {car.model} is already booked from {conflict.start_time} to {conflict.end_time}.",
        )

    coupon_obj = None
    if payload.couponCode and payload.couponCode.strip():
        code = payload.couponCode.strip().upper()
        coupon_obj = db.query(Coupon).filter(Coupon.code == code).first()

    pricing = calculate_server_pricing(
        price_per_day=car.price_per_day,
        deposit=car.deposit,
        start_str=payload.start,
        end_str=payload.end,
        extras=payload.extras,
        coupon_obj=coupon_obj,
        car_category=car.category,
    )

    booking = Booking(
        ref=generate_booking_ref(db),
        user_id=user.id if user else None,
        car_id=car.id,
        pickup=payload.pickup.strip(),
        dropoff=payload.dropoff.strip(),
        start_time=payload.start,
        end_time=payload.end,
        customer={
            "fullName": payload.customer.fullName,
            "email": payload.customer.email.lower(),
            "phone": payload.customer.phone,
            "license": payload.customer.license,
        },
        extras=payload.extras,
        pricing=pricing,
        status="Confirmed",
        payment_status="Pending",
        payment_method=None,
    )
    db.add(booking)
    if user:
        notif = Notification(
            user_id=user.id,
            title="Booking Confirmed",
            message=f"Your booking {booking.ref} for {car.brand} {car.model} is confirmed.",
            type="booking",
        )
        db.add(notif)
    db.commit()
    db.refresh(booking)
    return {"booking": serialize_booking(booking)}


@app.post("/api/bookings/{ref}/cancel")
def cancel_booking(ref: str, user: Optional[User] = Depends(get_optional_user), db: Session = Depends(get_db)):
    booking = db.query(Booking).filter(Booking.ref == ref).first()
    if not booking:
        raise HTTPException(status_code=404, detail="Booking not found.")
    if user and user.role != "admin" and booking.user_id and booking.user_id != user.id:
        raise HTTPException(status_code=403, detail="You can only cancel your own bookings.")
    if booking.status not in ACTIVE_STATUSES:
        raise HTTPException(status_code=400, detail="Booking is already cancelled or completed.")

    try:
        start_dt = parse_iso_dt(booking.start_time)
        if (start_dt - datetime.now()).total_seconds() < 86400:
            raise HTTPException(status_code=400, detail="Only active bookings starting in 24+ hours can be cancelled.")
    except HTTPException:
        raise
    except Exception:
        pass

    booking.status = "Cancelled"
    booking.cancelled_at = datetime.utcnow()
    if booking.payment_status == "Paid":
        booking.payment_status = "Refunded"

    if booking.user_id:
        notif = Notification(
            user_id=booking.user_id,
            title="Booking Cancelled",
            message=f"Your booking {booking.ref} has been cancelled successfully.",
            type="cancellation",
        )
        db.add(notif)

    db.commit()
    db.refresh(booking)
    return {"booking": serialize_booking(booking)}



@app.post("/api/bookings/{ref}/payment")
def update_booking_payment(ref: str, payload: PaymentUpdateRequest, db: Session = Depends(get_db)):
    booking = db.query(Booking).filter(Booking.ref == ref).first()
    if not booking:
        raise HTTPException(status_code=404, detail="Booking not found.")
    if booking.status == "Cancelled":
        raise HTTPException(status_code=400, detail="Cannot pay for a cancelled booking.")

    booking.payment_method = payload.paymentMethod
    booking.payment_status = payload.paymentStatus
    db.commit()
    db.refresh(booking)
    return {"booking": serialize_booking(booking)}


# --- Contact Messages ---
@app.post("/api/contact", status_code=status.HTTP_201_CREATED)
def submit_contact(payload: ContactCreateRequest, db: Session = Depends(get_db)):
    msg = ContactMessage(
        name=payload.name.strip(),
        email=payload.email.lower().strip(),
        phone=(payload.phone or "").strip(),
        subject=payload.subject.strip(),
        message=payload.message.strip(),
    )
    db.add(msg)
    db.commit()
    db.refresh(msg)
    return {"ok": True, "id": msg.id, "message": "Your message has been received. Our team will respond shortly."}


@app.get("/api/contact")
def list_contacts(admin: User = Depends(get_admin_user), db: Session = Depends(get_db)):
    msgs = db.query(ContactMessage).order_by(ContactMessage.created_at.desc()).all()
    return {
        "messages": [
            {
                "id": m.id,
                "name": m.name,
                "email": m.email,
                "phone": m.phone,
                "subject": m.subject,
                "message": m.message,
                "createdAt": m.created_at.isoformat() if m.created_at else None,
            }
            for m in msgs
        ]
    }


# --- Coupons Validation ---
@app.post("/api/coupons/validate")
def validate_coupon_endpoint(payload: CouponValidateRequest, db: Session = Depends(get_db)):
    car = db.query(Car).filter(Car.id == payload.carId).first()
    if not car:
        raise HTTPException(status_code=404, detail="Selected car does not exist.")

    code = payload.code.strip().upper()
    coupon = db.query(Coupon).filter(Coupon.code == code).first()
    if not coupon:
        raise HTTPException(status_code=400, detail="Invalid coupon code.")
    if not coupon.active:
        raise HTTPException(status_code=400, detail="This coupon code is no longer active.")

    try:
        pricing = calculate_server_pricing(
            price_per_day=car.price_per_day,
            deposit=car.deposit,
            start_str=payload.start,
            end_str=payload.end,
            extras=payload.extras or {},
            coupon_obj=coupon,
            car_category=car.category,
        )
    except ValueError as e:
        raise HTTPException(status_code=400, detail=str(e))

    if pricing.get("couponError"):
        raise HTTPException(status_code=400, detail=pricing["couponError"])

    return {
        "ok": True,
        "code": coupon.code,
        "description": coupon.description,
        "discount": pricing["discount"],
        "pricing": pricing,
    }


# --- Booking Receipt / Invoice ---
@app.get("/api/bookings/{ref}/receipt")
def get_booking_receipt(ref: str, db: Session = Depends(get_db)):
    booking = db.query(Booking).filter(Booking.ref == ref).first()
    if not booking:
        raise HTTPException(status_code=404, detail="Booking not found.")

    car = booking.car
    pricing = booking.pricing if isinstance(booking.pricing, dict) else {}
    receipt_data = {
        "invoiceNumber": f"INV-{booking.ref}",
        "bookingRef": booking.ref,
        "invoiceDate": booking.created_at.strftime("%d %b %Y") if booking.created_at else "",
        "status": booking.status,
        "paymentStatus": booking.payment_status,
        "paymentMethod": booking.payment_method or "Credit / Debit Card (Demo)",
        "customer": {
            "name": booking.customer.get("fullName", "Valued Customer"),
            "email": booking.customer.get("email", ""),
            "phone": booking.customer.get("phone", ""),
            "license": booking.customer.get("license", ""),
        },
        "vehicle": {
            "id": booking.car_id,
            "name": f"{car.brand} {car.model}" if car else "Vehicle",
            "category": car.category if car else "",
            "transmission": car.transmission if car else "",
            "fuel": car.fuel if car else "",
            "seats": car.seats if car else 5,
            "ratePerDay": car.price_per_day if car else 0,
            "image": car.image if car else "",
        },
        "schedule": {
            "pickupLocation": booking.pickup,
            "dropoffLocation": booking.dropoff,
            "startTime": booking.start_time,
            "endTime": booking.end_time,
            "days": pricing.get("days", 1),
        },
        "charges": {
            "baseRental": pricing.get("base", 0),
            "extras": pricing.get("extras", 0),
            "discount": pricing.get("discount", 0),
            "gst": pricing.get("tax", 0),
            "securityDeposit": pricing.get("deposit", 0),
            "totalAmount": pricing.get("total", 0),
        },
        "company": {
            "name": "Drivo Car Rental Private Limited",
            "taxId": "GSTIN33AAACD9999Z1Z",
            "supportEmail": "support@drivo.example",
            "supportPhone": "+91 98765 43210",
            "address": "RS Puram, Coimbatore, Tamil Nadu, 641002",
        },
    }
    return {"receipt": receipt_data}


# --- Customer Endpoints ---
@app.get("/api/bookings/my")
def list_my_bookings(user: User = Depends(get_current_user), db: Session = Depends(get_db)):
    bookings = (
        db.query(Booking)
        .filter(Booking.user_id == user.id)
        .order_by(Booking.created_at.desc())
        .all()
    )
    return {"bookings": [serialize_booking(b) for b in bookings]}


@app.get("/api/notifications")
def get_user_notifications(user: User = Depends(get_current_user), db: Session = Depends(get_db)):
    notifs = (
        db.query(Notification)
        .filter(Notification.user_id == user.id)
        .order_by(Notification.created_at.desc())
        .limit(20)
        .all()
    )
    return {"notifications": [serialize_notification(n) for n in notifs]}


@app.patch("/api/notifications/{notification_id}/read")
def mark_notification_read(
    notification_id: int, user: User = Depends(get_current_user), db: Session = Depends(get_db)
):
    notif = db.query(Notification).filter(Notification.id == notification_id, Notification.user_id == user.id).first()
    if not notif:
        raise HTTPException(status_code=404, detail="Notification not found.")
    notif.read = True
    db.commit()
    return {"ok": True}


# --- Verified Reviews ---
@app.get("/api/cars/{car_id}/reviews")
def list_car_reviews(car_id: int, db: Session = Depends(get_db)):
    reviews = db.query(Review).filter(Review.car_id == car_id).order_by(Review.created_at.desc()).all()
    return {"reviews": [serialize_review(r) for r in reviews]}


@app.post("/api/reviews", status_code=status.HTTP_201_CREATED)
def create_review(
    payload: ReviewCreateRequest, user: User = Depends(get_current_user), db: Session = Depends(get_db)
):
    booking = db.query(Booking).filter(Booking.ref == payload.bookingRef.strip()).first()
    if not booking:
        raise HTTPException(status_code=404, detail="Booking not found.")
    if booking.user_id != user.id and booking.customer.get("email", "").lower() != user.email.lower():
        raise HTTPException(status_code=403, detail="You can only review your own trips.")
    if booking.status != "Completed":
        raise HTTPException(status_code=400, detail="Reviews can only be submitted for completed trips.")

    existing = db.query(Review).filter(Review.booking_id == booking.id).first()
    if existing:
        raise HTTPException(status_code=400, detail="You have already submitted a review for this booking.")

    review = Review(
        user_id=user.id,
        car_id=booking.car_id,
        booking_id=booking.id,
        rating=payload.rating,
        title=payload.title.strip() if payload.title else "",
        comment=payload.comment.strip(),
    )
    db.add(review)

    # Recalculate car rating based on verified reviews
    car = db.query(Car).filter(Car.id == booking.car_id).first()
    if car:
        all_car_reviews = db.query(Review).filter(Review.car_id == car.id).all()
        total_ratings = sum(r.rating for r in all_car_reviews) + payload.rating
        count = len(all_car_reviews) + 1
        car.rating = round(total_ratings / count, 1)

    db.commit()
    db.refresh(review)
    return {"review": serialize_review(review)}


# --- Admin Dashboard & Fleet Management ---
@app.get("/api/admin/stats")
def get_admin_stats(admin: User = Depends(get_admin_user), db: Session = Depends(get_db)):
    total_cars = db.query(Car).count()
    available_cars = db.query(Car).filter(Car.available == True).count()
    total_bookings = db.query(Booking).count()
    active_bookings = db.query(Booking).filter(Booking.status == "Confirmed").count()
    completed_bookings = db.query(Booking).filter(Booking.status == "Completed").count()
    cancelled_bookings = db.query(Booking).filter(Booking.status == "Cancelled").count()
    total_users = db.query(User).count()

    all_bookings = db.query(Booking).all()
    revenue_total = 0
    paid_revenue = 0
    for b in all_bookings:
        if b.status in ("Confirmed", "Completed"):
            total_amt = b.pricing.get("total", 0) if isinstance(b.pricing, dict) else 0
            revenue_total += total_amt
            if b.payment_status == "Paid":
                paid_revenue += total_amt

    return {
        "totalCars": total_cars,
        "availableCars": available_cars,
        "totalBookings": total_bookings,
        "activeBookings": active_bookings,
        "completedBookings": completed_bookings,
        "cancelledBookings": cancelled_bookings,
        "totalUsers": total_users,
        "totalRevenue": revenue_total,
        "paidRevenue": paid_revenue,
        "pendingRevenue": max(0, revenue_total - paid_revenue),
    }


@app.get("/api/admin/bookings")
def list_admin_bookings(admin: User = Depends(get_admin_user), db: Session = Depends(get_db)):
    bookings = db.query(Booking).order_by(Booking.created_at.desc()).all()
    return {"bookings": [serialize_booking(b) for b in bookings]}


@app.patch("/api/admin/bookings/{booking_id}/status")
def update_booking_status_admin(
    booking_id: int,
    payload: BookingStatusUpdateRequest,
    admin: User = Depends(get_admin_user),
    db: Session = Depends(get_db),
):
    booking = db.query(Booking).filter(Booking.id == booking_id).first()
    if not booking:
        raise HTTPException(status_code=404, detail="Booking not found.")

    old_status = booking.status
    booking.status = payload.status
    if payload.paymentStatus:
        booking.payment_status = payload.paymentStatus
    if payload.status == "Cancelled":
        booking.cancelled_at = datetime.utcnow()
        if booking.payment_status == "Paid":
            booking.payment_status = "Refunded"

    if booking.user_id:
        car_name = f"{booking.car.brand} {booking.car.model}" if booking.car else "Vehicle"
        notif = Notification(
            user_id=booking.user_id,
            title=f"Booking Status: {payload.status}",
            message=f"Your booking {booking.ref} for {car_name} status was updated from {old_status} to {payload.status}.",
            type="booking" if payload.status != "Cancelled" else "cancellation",
        )
        db.add(notif)

    db.commit()
    db.refresh(booking)
    return {"booking": serialize_booking(booking)}



if __name__ == "__main__":
    import uvicorn

    host = os.getenv("HOST", "127.0.0.1")
    port = int(os.getenv("PORT", "8000"))
    uvicorn.run("main:app", host=host, port=port, reload=True)

