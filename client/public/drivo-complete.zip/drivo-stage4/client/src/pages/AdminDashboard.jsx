import { useState, useEffect, useMemo, useRef } from 'react';
import { Link, useNavigate } from 'react-router-dom';
import {
  Shield,
  Car,
  CalendarCheck,
  Users,
  IndianRupee,
  Plus,
  Trash2,
  Edit,
  CheckCircle2,
  XCircle,
  Search,
  RefreshCw,
  Mail,
  FileText,
  AlertTriangle,
  ArrowRight,
  Filter,
  UploadCloud,
  Image as ImageIcon,
} from 'lucide-react';
import toast from 'react-hot-toast';
import { useAuth } from '../context/AuthContext.jsx';
import { useCars } from '../context/CarContext.jsx';
import { apiRequest, uploadCarImage } from '../services/api.js';
import { resolveImageUrl } from '../utils/imageUrl.js';
import { formatINR } from '../utils/pricing.js';
import CarImage from '../components/CarImage.jsx';
import BookingReceiptModal from '../components/BookingReceiptModal.jsx';
import { locations } from '../data/homeContent.js';

export default function AdminDashboard() {
  const { user, isAuthenticated, isAdmin } = useAuth();
  const navigate = useNavigate();
  const { cars, refreshCars, toggleCarAvailability } = useCars();

  const [activeTab, setActiveTab] = useState('overview');
  const [stats, setStats] = useState(null);
  const [loadingStats, setLoadingStats] = useState(false);

  // Admin bookings
  const [bookings, setBookings] = useState([]);
  const [loadingBookings, setLoadingBookings] = useState(false);
  const [bookingSearch, setBookingSearch] = useState('');
  const [bookingFilter, setBookingFilter] = useState('all');

  // Contact messages
  const [messages, setMessages] = useState([]);
  const [loadingMessages, setLoadingMessages] = useState(false);

  // Selected receipt
  const [receiptRef, setReceiptRef] = useState(null);

  // Fleet management states
  const [carSearch, setCarSearch] = useState('');
  const [carCatFilter, setCarCatFilter] = useState('all');
  const [showAddCarModal, setShowAddCarModal] = useState(false);
  const [editingCar, setEditingCar] = useState(null);

  // Car image upload states
  const fileInputRef = useRef(null);
  const [selectedFile, setSelectedFile] = useState(null);
  const [previewUrl, setPreviewUrl] = useState(null);
  const [uploadingImage, setUploadingImage] = useState(false);
  const [imageMode, setImageMode] = useState('upload'); // 'upload' | 'url'

  // Form state for car create/edit
  const initialCarForm = {
    brand: '',
    model: '',
    year: 2024,
    category: 'SUV',
    fuel: 'Petrol',
    transmission: 'Automatic',
    seats: 5,
    pricePerDay: 3200,
    deposit: 6000,
    location: 'Coimbatore',
    image: '',
    available: true,
  };
  const [carForm, setCarForm] = useState(initialCarForm);
  const [savingCar, setSavingCar] = useState(false);

  // Fetch admin stats
  const fetchStats = async () => {
    setLoadingStats(true);
    try {
      const res = await apiRequest('/admin/stats');
      setStats(res);
    } catch (err) {
      toast.error('Failed to load admin metrics');
    } finally {
      setLoadingStats(false);
    }
  };

  // Fetch admin bookings
  const fetchBookings = async () => {
    setLoadingBookings(true);
    try {
      const res = await apiRequest('/admin/bookings');
      setBookings(res.bookings || []);
    } catch {
      toast.error('Failed to load all bookings');
    } finally {
      setLoadingBookings(false);
    }
  };

  // Fetch contact messages
  const fetchMessages = async () => {
    setLoadingMessages(true);
    try {
      const res = await apiRequest('/contact');
      setMessages(res.messages || []);
    } catch {
      toast.error('Failed to load contact messages');
    } finally {
      setLoadingMessages(false);
    }
  };

  useEffect(() => {
    if (isAuthenticated && isAdmin) {
      fetchStats();
      fetchBookings();
      fetchMessages();
    }
  }, [isAuthenticated, isAdmin]);

  // Handle Unauthorized / Non-admin
  if (!isAuthenticated) {
    return (
      <div className="container-x py-20 text-center">
        <div className="mx-auto max-w-md rounded-3xl border border-neutral-200 bg-white p-8 shadow-card">
          <Shield size={40} className="mx-auto text-amber-500" />
          <h1 className="mt-4 text-2xl font-black">Admin Authentication Required</h1>
          <p className="mt-2 text-sm text-neutral-600">Please log in with an administrator account to access this portal.</p>
          <Link to="/login" className="btn-dark mt-6 inline-block">Log in as Admin</Link>
        </div>
      </div>
    );
  }

  if (!isAdmin) {
    return (
      <div className="container-x py-20 text-center">
        <div className="mx-auto max-w-md rounded-3xl border border-red-200 bg-red-50 p-8 shadow-card">
          <AlertTriangle size={40} className="mx-auto text-red-600" />
          <h1 className="mt-4 text-2xl font-black text-red-900">Access Denied (403 Forbidden)</h1>
          <p className="mt-2 text-sm text-red-700">You do not have administrative privileges. Only authorized staff may view the admin dashboard.</p>
          <div className="mt-6 flex justify-center gap-3">
            <Link to="/dashboard" className="btn-dark">Customer Dashboard</Link>
            <Link to="/" className="btn-outline">Go to Home</Link>
          </div>
        </div>
      </div>
    );
  }

  // Filtered cars
  const filteredCars = cars.filter((c) => {
    const matchQ = `${c.brand} ${c.model}`.toLowerCase().includes(carSearch.toLowerCase());
    const matchCat = carCatFilter === 'all' || c.category === carCatFilter;
    return matchQ && matchCat;
  });

  // Filtered bookings
  const filteredBookings = bookings.filter((b) => {
    const q = bookingSearch.toLowerCase();
    const matchQ =
      b.ref.toLowerCase().includes(q) ||
      (b.customer?.fullName || '').toLowerCase().includes(q) ||
      (b.customer?.email || '').toLowerCase().includes(q) ||
      (b.car?.brand || '').toLowerCase().includes(q) ||
      (b.car?.model || '').toLowerCase().includes(q);
    const matchStatus = bookingFilter === 'all' || b.status === bookingFilter;
    return matchQ && matchStatus;
  });

  // File upload handlers
  const handleFileSelect = (e) => {
    const file = e.target.files?.[0];
    if (!file) return;

    const allowedTypes = ['image/jpeg', 'image/png', 'image/webp', 'image/jpg'];
    if (!allowedTypes.includes(file.type)) {
      toast.error('Invalid image type. Please select a JPG, PNG, or WEBP image.');
      if (fileInputRef.current) fileInputRef.current.value = '';
      return;
    }

    if (file.size > 5 * 1024 * 1024) {
      toast.error('File size exceeds 5 MB. Please select a smaller image.');
      if (fileInputRef.current) fileInputRef.current.value = '';
      return;
    }

    if (previewUrl && previewUrl.startsWith('blob:')) {
      URL.revokeObjectURL(previewUrl);
    }

    setSelectedFile(file);
    const objectUrl = URL.createObjectURL(file);
    setPreviewUrl(objectUrl);
    toast.success(`Selected "${file.name}" (${(file.size / 1024).toFixed(0)} KB)`);
  };

  const handleRemoveFile = () => {
    if (previewUrl && previewUrl.startsWith('blob:')) {
      URL.revokeObjectURL(previewUrl);
    }
    setSelectedFile(null);
    setPreviewUrl(null);
    if (fileInputRef.current) fileInputRef.current.value = '';
  };

  const openAddModal = () => {
    setEditingCar(null);
    setSelectedFile(null);
    if (previewUrl && previewUrl.startsWith('blob:')) URL.revokeObjectURL(previewUrl);
    setPreviewUrl(null);
    setImageMode('upload');
    setCarForm({
      ...initialCarForm,
      image: '',
    });
    setShowAddCarModal(true);
  };

  const openEditModal = (c) => {
    setEditingCar(c);
    setSelectedFile(null);
    if (previewUrl && previewUrl.startsWith('blob:')) URL.revokeObjectURL(previewUrl);
    setPreviewUrl(null);
    setImageMode('upload');
    setCarForm({
      brand: c.brand,
      model: c.model,
      year: c.year,
      category: c.category,
      fuel: c.fuel,
      transmission: c.transmission,
      seats: c.seats,
      pricePerDay: c.pricePerDay,
      deposit: c.deposit,
      location: c.location,
      image: c.image || '',
      available: c.available,
    });
    setShowAddCarModal(true);
  };

  const closeCarModal = () => {
    setShowAddCarModal(false);
    setEditingCar(null);
    setSelectedFile(null);
    if (previewUrl && previewUrl.startsWith('blob:')) URL.revokeObjectURL(previewUrl);
    setPreviewUrl(null);
    if (fileInputRef.current) fileInputRef.current.value = '';
    setCarForm(initialCarForm);
  };

  // Handle Car Form Submit (Create or Update with Image Upload)
  const handleSaveCar = async (e) => {
    e.preventDefault();
    if (!carForm.brand.trim() || !carForm.model.trim()) {
      toast.error('Brand and model are required');
      return;
    }

    let resolvedImage = (carForm.image || '').trim();

    // If an image file was selected by the admin, upload it first to FastAPI backend
    if (selectedFile) {
      setUploadingImage(true);
      try {
        const uploadRes = await uploadCarImage(selectedFile);
        resolvedImage = uploadRes.url;
      } catch (err) {
        toast.error(err.message || 'Image upload failed. Please try again.');
        setUploadingImage(false);
        return;
      } finally {
        setUploadingImage(false);
      }
    } else if (!editingCar && !resolvedImage) {
      toast.error('Please upload a car image or provide an image URL');
      return;
    }

    setSavingCar(true);
    try {
      const finalImage = resolvedImage || editingCar?.image || '';
      const payload = {
        ...carForm,
        image: finalImage,
        images: [finalImage],
        year: Number(carForm.year),
        seats: Number(carForm.seats),
        pricePerDay: Number(carForm.pricePerDay),
        deposit: Number(carForm.deposit),
      };

      if (editingCar) {
        await apiRequest(`/cars/${editingCar.id}`, { method: 'PUT', body: payload });
        toast.success(`Updated ${carForm.brand} ${carForm.model}`);
      } else {
        await apiRequest('/cars', { method: 'POST', body: payload });
        toast.success(`Added ${carForm.brand} ${carForm.model} to catalog!`);
      }
      refreshCars();
      fetchStats();
      closeCarModal();
    } catch (err) {
      toast.error(err.message || 'Operation failed');
    } finally {
      setSavingCar(false);
    }
  };

  // Delete Car
  const handleDeleteCar = async (carId, name) => {
    if (!window.confirm(`Are you sure you want to permanently delete "${name}" from the fleet?`)) return;
    try {
      await apiRequest(`/cars/${carId}`, { method: 'DELETE' });
      toast.success(`${name} deleted`);
      refreshCars();
      fetchStats();
    } catch (err) {
      toast.error(err.message || 'Could not delete vehicle');
    }
  };

  // Update Booking Status
  const handleUpdateBookingStatus = async (bookingId, newStatus, newPaymentStatus) => {
    try {
      const body = { status: newStatus };
      if (newPaymentStatus) body.paymentStatus = newPaymentStatus;
      await apiRequest(`/admin/bookings/${bookingId}/status`, {
        method: 'PATCH',
        body,
      });
      toast.success(`Booking status updated to ${newStatus}`);
      fetchBookings();
      fetchStats();
    } catch (err) {
      toast.error(err.message || 'Could not update booking');
    }
  };

  return (
    <div className="container-x py-10">
      {/* Top Header */}
      <div className="flex flex-col sm:flex-row sm:items-center sm:justify-between gap-4 border-b border-neutral-200 pb-6">
        <div>
          <div className="flex items-center gap-2">
            <span className="grid h-8 w-8 place-items-center rounded-xl bg-ink text-white">
              <Shield size={18} />
            </span>
            <h1 className="text-2xl font-black text-ink">Drivo Admin Portal</h1>
            <span className="rounded-full bg-accent-soft px-3 py-0.5 text-xs font-bold text-accent">
              Authorized Staff
            </span>
          </div>
          <p className="mt-1 text-xs text-neutral-500">
            Real-time MySQL fleet management, live revenue analytics, and booking controls.
          </p>
        </div>

        <div className="flex items-center gap-2">
          <button
            onClick={() => {
              fetchStats();
              fetchBookings();
              fetchMessages();
              refreshCars();
              toast.success('Admin data refreshed');
            }}
            className="btn-outline text-xs px-3 py-2 flex items-center gap-1.5"
            title="Refresh database records"
          >
            <RefreshCw size={14} className={loadingStats ? 'animate-spin' : ''} /> Refresh
          </button>
          <Link to="/dashboard" className="btn-outline text-xs px-3 py-2">
            Customer View
          </Link>
        </div>
      </div>

      {/* Tabs */}
      <div className="mt-6 flex flex-wrap gap-2 border-b border-neutral-200 pb-3">
        {[
          ['overview', 'Overview & Analytics'],
          ['fleet', `Fleet Management (${cars.length})`],
          ['bookings', `All Bookings (${bookings.length})`],
          ['inquiries', `Customer Messages (${messages.length})`],
        ].map(([key, label]) => (
          <button
            key={key}
            onClick={() => setActiveTab(key)}
            className={`rounded-full px-4 py-2 text-xs font-bold transition ${
              activeTab === key
                ? 'bg-ink text-white shadow'
                : 'bg-neutral-100 text-neutral-600 hover:bg-neutral-200'
            }`}
          >
            {label}
          </button>
        ))}
      </div>

      {/* TAB 1: OVERVIEW & ANALYTICS */}
      {activeTab === 'overview' && (
        <div className="mt-8 space-y-8">
          {stats && (
            <div className="grid gap-4 sm:grid-cols-2 lg:grid-cols-4">
              <div className="rounded-3xl border border-neutral-200 bg-white p-5 shadow-card">
                <span className="text-xs font-bold uppercase text-neutral-400">Total Fleet Vehicles</span>
                <p className="mt-2 text-3xl font-extrabold text-ink">{stats.totalCars}</p>
                <p className="mt-1 text-xs text-green-600 font-semibold">{stats.availableCars} vehicles active & ready</p>
              </div>

              <div className="rounded-3xl border border-neutral-200 bg-white p-5 shadow-card">
                <span className="text-xs font-bold uppercase text-neutral-400">Total Bookings</span>
                <p className="mt-2 text-3xl font-extrabold text-ink">{stats.totalBookings}</p>
                <p className="mt-1 text-xs text-neutral-500">{stats.activeBookings} confirmed / {stats.completedBookings} completed</p>
              </div>

              <div className="rounded-3xl border border-neutral-200 bg-white p-5 shadow-card">
                <span className="text-xs font-bold uppercase text-neutral-400">Registered Users</span>
                <p className="mt-2 text-3xl font-extrabold text-ink">{stats.totalUsers}</p>
                <p className="mt-1 text-xs text-neutral-500">Persistent database accounts</p>
              </div>

              <div className="rounded-3xl border border-neutral-200 bg-white p-5 shadow-card">
                <span className="text-xs font-bold uppercase text-neutral-400">Total Rental Volume</span>
                <p className="mt-2 text-3xl font-extrabold text-ink">{formatINR(stats.totalRevenue)}</p>
                <p className="mt-1 text-xs text-green-600 font-semibold">{formatINR(stats.paidRevenue)} paid</p>
              </div>
            </div>
          )}

          {/* Quick Actions Card */}
          <div className="grid gap-6 md:grid-cols-2">
            <div className="rounded-3xl border border-neutral-200 bg-white p-6 shadow-card">
              <h3 className="font-extrabold text-lg text-ink">Fleet Controls</h3>
              <p className="mt-1 text-xs text-neutral-500">Quickly add new vehicles or configure daily rental rates.</p>
              <div className="mt-4 flex flex-wrap gap-2">
                <button
                  onClick={openAddModal}
                  className="btn-dark text-xs flex items-center gap-1.5"
                >
                  <Plus size={15} /> Add New Car
                </button>
                <button onClick={() => setActiveTab('fleet')} className="btn-outline text-xs">
                  Manage Fleet ({cars.length})
                </button>
              </div>
            </div>

            <div className="rounded-3xl border border-neutral-200 bg-white p-6 shadow-card">
              <h3 className="font-extrabold text-lg text-ink">Booking Dispatch</h3>
              <p className="mt-1 text-xs text-neutral-500">Process confirmed bookings, print tax receipts, or handle refunds.</p>
              <div className="mt-4 flex flex-wrap gap-2">
                <button onClick={() => setActiveTab('bookings')} className="btn-dark text-xs flex items-center gap-1.5">
                  <CalendarCheck size={15} /> Review Bookings ({bookings.length})
                </button>
                <button onClick={() => setActiveTab('inquiries')} className="btn-outline text-xs flex items-center gap-1.5">
                  <Mail size={15} /> Inquiries ({messages.length})
                </button>
              </div>
            </div>
          </div>
        </div>
      )}

      {/* TAB 2: FLEET MANAGEMENT */}
      {activeTab === 'fleet' && (
        <div className="mt-8 space-y-6">
          <div className="flex flex-col sm:flex-row sm:items-center sm:justify-between gap-4">
            <div className="flex flex-wrap items-center gap-3 flex-1">
              <div className="relative flex-1 max-w-sm">
                <Search size={15} className="absolute left-3 top-1/2 -translate-y-1/2 text-neutral-400" />
                <input
                  type="search"
                  placeholder="Filter by brand or model..."
                  value={carSearch}
                  onChange={(e) => setCarSearch(e.target.value)}
                  className="field pl-9 text-xs"
                />
              </div>

              <select
                value={carCatFilter}
                onChange={(e) => setCarCatFilter(e.target.value)}
                className="field text-xs sm:w-44"
              >
                <option value="all">All Categories</option>
                {['Hatchback', 'Sedan', 'SUV', 'MUV / MPV', 'Luxury', 'Electric Vehicles'].map((c) => (
                  <option key={c} value={c}>{c}</option>
                ))}
              </select>
            </div>

            <button
              onClick={openAddModal}
              className="btn-dark text-xs flex items-center gap-1.5 shrink-0"
            >
              <Plus size={15} /> Add Vehicle to Fleet
            </button>
          </div>

          <p className="text-xs text-neutral-500">Showing {filteredCars.length} of {cars.length} cars in catalog</p>

          <div className="overflow-x-auto rounded-3xl border border-neutral-200 bg-white shadow-card">
            <table className="w-full text-left text-xs">
              <thead className="border-b border-neutral-200 bg-neutral-50 text-[11px] font-bold uppercase tracking-wider text-neutral-500">
                <tr>
                  <th className="p-4">Car ID & Vehicle</th>
                  <th className="p-4">Category</th>
                  <th className="p-4">Specs</th>
                  <th className="p-4">Location</th>
                  <th className="p-4">Daily Rate</th>
                  <th className="p-4">Status</th>
                  <th className="p-4 text-right">Actions</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-neutral-100">
                {filteredCars.map((c) => (
                  <tr key={c.id} className="hover:bg-neutral-50/70 transition">
                    <td className="p-4">
                      <div className="flex items-center gap-3">
                        <div className="h-10 w-14 shrink-0 overflow-hidden rounded-xl bg-neutral-100">
                          <CarImage src={c.image} alt="" className="h-full w-full object-cover" />
                        </div>
                        <div>
                          <p className="font-extrabold text-ink">{c.brand} {c.model}</p>
                          <span className="font-mono text-[10px] text-neutral-400">ID: #{c.id} · {c.year}</span>
                        </div>
                      </div>
                    </td>
                    <td className="p-4">
                      <span className="rounded-full bg-neutral-100 px-2.5 py-1 font-semibold text-[11px]">
                        {c.category}
                      </span>
                    </td>
                    <td className="p-4 text-neutral-600">
                      {c.fuel} · {c.transmission} · {c.seats} seats
                    </td>
                    <td className="p-4 text-neutral-600 font-medium">
                      {c.location}
                    </td>
                    <td className="p-4 font-mono font-bold text-ink">
                      {formatINR(c.pricePerDay)}
                    </td>
                    <td className="p-4">
                      <button
                        onClick={() => toggleCarAvailability(c.id, !c.available)}
                        className={`inline-flex items-center gap-1 rounded-full px-2.5 py-0.5 text-[11px] font-bold ${
                          c.available
                            ? 'bg-green-100 text-green-800 hover:bg-green-200'
                            : 'bg-red-100 text-red-800 hover:bg-red-200'
                        }`}
                        title="Click to toggle availability"
                      >
                        {c.available ? <CheckCircle2 size={12} /> : <XCircle size={12} />}
                        {c.available ? 'Available' : 'Unavailable'}
                      </button>
                    </td>
                    <td className="p-4 text-right">
                      <div className="flex items-center justify-end gap-1.5">
                        <button
                          onClick={() => openEditModal(c)}
                          className="grid h-8 w-8 place-items-center rounded-lg border border-neutral-200 text-neutral-600 hover:bg-neutral-100"
                          title="Edit vehicle"
                        >
                          <Edit size={14} />
                        </button>
                        <button
                          onClick={() => handleDeleteCar(c.id, `${c.brand} ${c.model}`)}
                          className="grid h-8 w-8 place-items-center rounded-lg border border-neutral-200 text-red-600 hover:bg-red-50"
                          title="Delete vehicle"
                        >
                          <Trash2 size={14} />
                        </button>
                      </div>
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        </div>
      )}

      {/* TAB 3: ALL BOOKINGS */}
      {activeTab === 'bookings' && (
        <div className="mt-8 space-y-6">
          <div className="flex flex-col sm:flex-row sm:items-center sm:justify-between gap-3">
            <div className="flex flex-wrap items-center gap-3 flex-1">
              <div className="relative flex-1 max-w-sm">
                <Search size={15} className="absolute left-3 top-1/2 -translate-y-1/2 text-neutral-400" />
                <input
                  type="search"
                  placeholder="Search ref, customer, email, car..."
                  value={bookingSearch}
                  onChange={(e) => setBookingSearch(e.target.value)}
                  className="field pl-9 text-xs"
                />
              </div>

              <select
                value={bookingFilter}
                onChange={(e) => setBookingFilter(e.target.value)}
                className="field text-xs sm:w-40"
              >
                <option value="all">All Statuses</option>
                <option value="Confirmed">Confirmed</option>
                <option value="Completed">Completed</option>
                <option value="Cancelled">Cancelled</option>
              </select>
            </div>
          </div>

          <div className="overflow-x-auto rounded-3xl border border-neutral-200 bg-white shadow-card">
            <table className="w-full text-left text-xs">
              <thead className="border-b border-neutral-200 bg-neutral-50 text-[11px] font-bold uppercase tracking-wider text-neutral-500">
                <tr>
                  <th className="p-4">Booking Ref</th>
                  <th className="p-4">Customer Details</th>
                  <th className="p-4">Car Reserved</th>
                  <th className="p-4">Dates</th>
                  <th className="p-4">Total Amount</th>
                  <th className="p-4">Status & Payment</th>
                  <th className="p-4 text-right">Actions</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-neutral-100">
                {filteredBookings.map((b) => (
                  <tr key={b.id || b.ref} className="hover:bg-neutral-50/70 transition">
                    <td className="p-4">
                      <span className="font-mono font-bold text-ink">{b.ref}</span>
                      <p className="text-[10px] text-neutral-400 mt-0.5">{b.pickup} → {b.dropoff}</p>
                    </td>
                    <td className="p-4">
                      <p className="font-extrabold text-ink">{b.customer?.fullName}</p>
                      <p className="text-neutral-500">{b.customer?.email}</p>
                      <p className="text-neutral-400 text-[10px]">{b.customer?.phone}</p>
                    </td>
                    <td className="p-4">
                      <p className="font-bold text-ink">{b.car?.brand} {b.car?.model}</p>
                      <span className="text-[10px] text-neutral-400">{b.car?.category}</span>
                    </td>
                    <td className="p-4 text-neutral-600">
                      <div>Start: {new Date(b.start).toLocaleDateString('en-IN', { month: 'short', day: 'numeric' })}</div>
                      <div className="text-[10px] text-neutral-400">End: {new Date(b.end).toLocaleDateString('en-IN', { month: 'short', day: 'numeric' })}</div>
                    </td>
                    <td className="p-4 font-mono font-extrabold text-ink">
                      {formatINR(b.pricing?.total || 0)}
                    </td>
                    <td className="p-4">
                      <div className="space-y-1">
                        <span
                          className={`inline-block rounded-full px-2 py-0.5 text-[10px] font-bold ${
                            b.status === 'Confirmed'
                              ? 'bg-blue-100 text-blue-800'
                              : b.status === 'Completed'
                              ? 'bg-green-100 text-green-800'
                              : 'bg-neutral-100 text-neutral-600'
                          }`}
                        >
                          {b.status}
                        </span>
                        <span
                          className={`block font-semibold text-[10px] ${
                            b.paymentStatus === 'Paid' ? 'text-green-700' : 'text-amber-700'
                          }`}
                        >
                          Payment: {b.paymentStatus}
                        </span>
                      </div>
                    </td>
                    <td className="p-4 text-right">
                      <div className="flex items-center justify-end gap-1.5">
                        <button
                          onClick={() => setReceiptRef(b.ref)}
                          className="btn-outline px-2 py-1 text-[11px] flex items-center gap-1"
                          title="Print or view tax invoice"
                        >
                          <FileText size={13} /> Invoice
                        </button>
                        {b.status === 'Confirmed' && (
                          <button
                            onClick={() => handleUpdateBookingStatus(b.id, 'Completed', 'Paid')}
                            className="rounded-lg bg-green-50 px-2 py-1 text-[11px] font-bold text-green-700 hover:bg-green-100"
                            title="Mark trip as completed"
                          >
                            Complete
                          </button>
                        )}
                        {b.status === 'Confirmed' && (
                          <button
                            onClick={() => handleUpdateBookingStatus(b.id, 'Cancelled')}
                            className="rounded-lg bg-red-50 px-2 py-1 text-[11px] font-bold text-red-700 hover:bg-red-100"
                            title="Cancel booking"
                          >
                            Cancel
                          </button>
                        )}
                      </div>
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        </div>
      )}

      {/* TAB 4: CUSTOMER INQUIRIES */}
      {activeTab === 'inquiries' && (
        <div className="mt-8 space-y-4">
          <p className="text-xs text-neutral-500">Contact form messages submitted through the website</p>
          <div className="grid gap-4 md:grid-cols-2">
            {messages.map((m) => (
              <div key={m.id} className="rounded-3xl border border-neutral-200 bg-white p-6 shadow-card">
                <div className="flex items-start justify-between gap-2 border-b border-neutral-100 pb-3">
                  <div>
                    <h3 className="font-extrabold text-sm text-ink">{m.name}</h3>
                    <p className="text-xs text-neutral-500">{m.email} · {m.phone || 'No phone'}</p>
                  </div>
                  <span className="text-[10px] text-neutral-400 font-mono">
                    {new Date(m.createdAt).toLocaleDateString('en-IN', { month: 'short', day: 'numeric', year: 'numeric' })}
                  </span>
                </div>
                <div className="mt-3">
                  <p className="font-bold text-xs text-ink">Subject: {m.subject}</p>
                  <p className="mt-1.5 text-xs text-neutral-600 leading-relaxed bg-neutral-50 p-3 rounded-2xl">{m.message}</p>
                </div>
              </div>
            ))}
          </div>
        </div>
      )}

      {/* CREATE / EDIT CAR MODAL */}
      {showAddCarModal && (
        <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/60 p-4 backdrop-blur-sm">
          <div className="relative max-h-[90vh] w-full max-w-xl overflow-y-auto rounded-3xl bg-white p-6 shadow-2xl sm:p-8">
            <div className="flex items-center justify-between border-b border-neutral-100 pb-4">
              <h2 className="text-lg font-black text-ink">
                {editingCar ? `Edit ${editingCar.brand} ${editingCar.model}` : 'Add Vehicle to Fleet'}
              </h2>
              <button
                onClick={closeCarModal}
                className="grid h-8 w-8 place-items-center rounded-full hover:bg-neutral-100"
              >
                <XCircle size={20} />
              </button>
            </div>

            <form onSubmit={handleSaveCar} className="mt-6 space-y-4">
              <div className="grid grid-cols-2 gap-3">
                <div>
                  <label className="text-xs font-bold text-neutral-600">Brand</label>
                  <input
                    type="text"
                    required
                    value={carForm.brand}
                    onChange={(e) => setCarForm({ ...carForm, brand: e.target.value })}
                    className="field mt-1 text-xs"
                    placeholder="e.g. Toyota"
                  />
                </div>
                <div>
                  <label className="text-xs font-bold text-neutral-600">Model</label>
                  <input
                    type="text"
                    required
                    value={carForm.model}
                    onChange={(e) => setCarForm({ ...carForm, model: e.target.value })}
                    className="field mt-1 text-xs"
                    placeholder="e.g. Fortuner"
                  />
                </div>
              </div>

              <div className="grid grid-cols-3 gap-3">
                <div>
                  <label className="text-xs font-bold text-neutral-600">Category</label>
                  <select
                    value={carForm.category}
                    onChange={(e) => setCarForm({ ...carForm, category: e.target.value })}
                    className="field mt-1 text-xs"
                  >
                    {['SUV', 'Sedan', 'Hatchback', 'MUV / MPV', 'Luxury', 'Electric Vehicles'].map((c) => (
                      <option key={c} value={c}>{c}</option>
                    ))}
                  </select>
                </div>
                <div>
                  <label className="text-xs font-bold text-neutral-600">Fuel</label>
                  <select
                    value={carForm.fuel}
                    onChange={(e) => setCarForm({ ...carForm, fuel: e.target.value })}
                    className="field mt-1 text-xs"
                  >
                    <option value="Petrol">Petrol</option>
                    <option value="Diesel">Diesel</option>
                    <option value="Electric">Electric</option>
                    <option value="Hybrid">Hybrid</option>
                  </select>
                </div>
                <div>
                  <label className="text-xs font-bold text-neutral-600">Transmission</label>
                  <select
                    value={carForm.transmission}
                    onChange={(e) => setCarForm({ ...carForm, transmission: e.target.value })}
                    className="field mt-1 text-xs"
                  >
                    <option value="Automatic">Automatic</option>
                    <option value="Manual">Manual</option>
                  </select>
                </div>
              </div>

              <div className="grid grid-cols-3 gap-3">
                <div>
                  <label className="text-xs font-bold text-neutral-600">Year</label>
                  <input
                    type="number"
                    value={carForm.year}
                    onChange={(e) => setCarForm({ ...carForm, year: e.target.value })}
                    className="field mt-1 text-xs"
                  />
                </div>
                <div>
                  <label className="text-xs font-bold text-neutral-600">Seats</label>
                  <input
                    type="number"
                    value={carForm.seats}
                    onChange={(e) => setCarForm({ ...carForm, seats: e.target.value })}
                    className="field mt-1 text-xs"
                  />
                </div>
                <div>
                  <label className="text-xs font-bold text-neutral-600">Daily Rate (₹)</label>
                  <input
                    type="number"
                    value={carForm.pricePerDay}
                    onChange={(e) => setCarForm({ ...carForm, pricePerDay: e.target.value })}
                    className="field mt-1 text-xs"
                  />
                </div>
              </div>

              <div className="grid grid-cols-2 gap-3">
                <div>
                  <label className="text-xs font-bold text-neutral-600">City / Location</label>
                  <select
                    value={carForm.location}
                    onChange={(e) => setCarForm({ ...carForm, location: e.target.value })}
                    className="field mt-1 text-xs"
                  >
                    {locations.map((loc) => (
                      <option key={loc} value={loc}>{loc}</option>
                    ))}
                  </select>
                </div>
                <div>
                  <label className="text-xs font-bold text-neutral-600">Security Deposit (₹)</label>
                  <input
                    type="number"
                    value={carForm.deposit}
                    onChange={(e) => setCarForm({ ...carForm, deposit: e.target.value })}
                    className="field mt-1 text-xs"
                  />
                </div>
              </div>

              {/* UPLOAD CAR IMAGE & LIVE PREVIEW */}
              <div className="space-y-2 rounded-2xl border border-neutral-200 bg-neutral-50 p-4">
                <div className="flex items-center justify-between">
                  <label className="text-xs font-bold text-neutral-800 flex items-center gap-1.5">
                    <ImageIcon size={14} className="text-accent" />
                    Car Image <span className="text-red-500">*</span>
                  </label>
                  <div className="flex rounded-lg bg-neutral-200 p-0.5 text-[11px] font-semibold">
                    <button
                      type="button"
                      onClick={() => setImageMode('upload')}
                      className={`rounded-md px-2.5 py-0.5 transition ${
                        imageMode === 'upload' ? 'bg-white shadow text-ink' : 'text-neutral-600 hover:text-ink'
                      }`}
                    >
                      Upload File
                    </button>
                    <button
                      type="button"
                      onClick={() => setImageMode('url')}
                      className={`rounded-md px-2.5 py-0.5 transition ${
                        imageMode === 'url' ? 'bg-white shadow text-ink' : 'text-neutral-600 hover:text-ink'
                      }`}
                    >
                      Image URL
                    </button>
                  </div>
                </div>

                {imageMode === 'upload' ? (
                  <div className="space-y-3">
                    <input
                      type="file"
                      ref={fileInputRef}
                      onChange={handleFileSelect}
                      accept="image/jpeg,image/png,image/webp,image/jpg"
                      className="hidden"
                    />

                    {/* Preview box if a file was selected or if editing an existing car */}
                    {(previewUrl || (editingCar && editingCar.image)) ? (
                      <div className="relative overflow-hidden rounded-2xl border border-neutral-200 bg-white p-3 shadow-sm">
                        <div className="flex items-center gap-4">
                          <div className="h-24 w-36 shrink-0 overflow-hidden rounded-xl bg-neutral-100 border border-neutral-200">
                            <img
                              src={previewUrl || resolveImageUrl(editingCar?.image)}
                              alt="Car Preview"
                              className="h-full w-full object-cover"
                            />
                          </div>
                          <div className="flex-1 min-w-0">
                            <div className="flex items-center gap-1.5">
                              <span
                                className={`rounded-full px-2 py-0.5 text-[10px] font-bold ${
                                  selectedFile ? 'bg-green-100 text-green-700' : 'bg-neutral-100 text-neutral-700'
                                }`}
                              >
                                {selectedFile ? 'New Image Selected' : 'Current Saved Image'}
                              </span>
                            </div>
                            <p className="mt-1 truncate text-xs font-bold text-ink">
                              {selectedFile ? selectedFile.name : (editingCar ? `${editingCar.brand} ${editingCar.model}` : 'Vehicle Image')}
                            </p>
                            {selectedFile && (
                              <p className="text-[11px] text-neutral-500">
                                Size: {(selectedFile.size / 1024).toFixed(0)} KB · Type: {selectedFile.type.split('/')[1]?.toUpperCase()}
                              </p>
                            )}
                            <div className="mt-2.5 flex items-center gap-2">
                              <button
                                type="button"
                                onClick={() => fileInputRef.current?.click()}
                                className="btn-outline px-2.5 py-1 text-[11px] flex items-center gap-1"
                              >
                                <UploadCloud size={13} /> {selectedFile ? 'Change Image' : 'Upload Replacement'}
                              </button>
                              {selectedFile && (
                                <button
                                  type="button"
                                  onClick={handleRemoveFile}
                                  className="rounded-lg px-2.5 py-1 text-[11px] font-semibold text-red-600 hover:bg-red-50"
                                >
                                  Remove
                                </button>
                              )}
                            </div>
                          </div>
                        </div>
                      </div>
                    ) : (
                      /* Drag & drop / upload button */
                      <div
                        onClick={() => fileInputRef.current?.click()}
                        className="group flex cursor-pointer flex-col items-center justify-center rounded-2xl border-2 border-dashed border-neutral-300 bg-white p-6 text-center transition hover:border-accent hover:bg-accent-soft/10"
                      >
                        <div className="grid h-12 w-12 place-items-center rounded-2xl bg-neutral-100 text-neutral-600 group-hover:bg-accent-soft group-hover:text-accent transition">
                          <UploadCloud size={24} />
                        </div>
                        <p className="mt-2 text-xs font-bold text-ink">
                          Choose Image to Upload
                        </p>
                        <p className="mt-0.5 text-[11px] text-neutral-500">
                          JPG, JPEG, PNG, or WEBP (Max size: 5 MB)
                        </p>
                        <button
                          type="button"
                          className="btn-outline mt-3 px-3 py-1 text-xs pointer-events-none"
                        >
                          Choose File
                        </button>
                      </div>
                    )}
                  </div>
                ) : (
                  <div>
                    <input
                      type="url"
                      value={carForm.image}
                      onChange={(e) => setCarForm({ ...carForm, image: e.target.value })}
                      placeholder="https://images.unsplash.com/..."
                      className="field text-xs bg-white"
                    />
                    {carForm.image && (
                      <div className="mt-2 h-20 w-32 overflow-hidden rounded-xl border border-neutral-200">
                        <img
                          src={resolveImageUrl(carForm.image)}
                          alt="URL preview"
                          className="h-full w-full object-cover"
                          onError={(e) => (e.currentTarget.style.display = 'none')}
                        />
                      </div>
                    )}
                  </div>
                )}
              </div>

              <div className="flex items-center gap-2 pt-2">
                <input
                  type="checkbox"
                  id="car-available"
                  checked={carForm.available}
                  onChange={(e) => setCarForm({ ...carForm, available: e.target.checked })}
                  className="rounded border-neutral-300"
                />
                <label htmlFor="car-available" className="text-xs font-bold text-neutral-700">
                  Mark as Available for Rent
                </label>
              </div>

              <div className="flex justify-end gap-3 pt-4 border-t border-neutral-100">
                <button
                  type="button"
                  onClick={closeCarModal}
                  className="btn-outline text-xs"
                >
                  Cancel
                </button>
                <button
                  type="submit"
                  disabled={savingCar || uploadingImage}
                  className="btn-dark text-xs flex items-center gap-1.5"
                >
                  {uploadingImage ? 'Uploading Image...' : savingCar ? 'Saving...' : editingCar ? 'Save Changes' : 'Create Listing'}
                </button>
              </div>
            </form>
          </div>
        </div>
      )}

      {/* INVOICE MODAL */}
      {receiptRef && (
        <BookingReceiptModal bookingRef={receiptRef} onClose={() => setReceiptRef(null)} />
      )}
    </div>
  );
}
