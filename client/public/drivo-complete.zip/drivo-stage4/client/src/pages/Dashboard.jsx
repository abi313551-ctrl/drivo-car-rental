import { useMemo, useState, useEffect } from 'react';
import { Link } from 'react-router-dom';
import {
  CalendarCheck,
  Heart,
  IndianRupee,
  User,
  Car,
  Shield,
  LogOut,
  Plus,
  CheckCircle2,
  XCircle,
  FileText,
  Clock,
  Star,
  Bell,
  AlertCircle,
  ArrowRight,
  ShieldCheck,
} from 'lucide-react';
import toast from 'react-hot-toast';
import { useAuth } from '../context/AuthContext.jsx';
import { useCars } from '../context/CarContext.jsx';
import { useBookings } from '../context/BookingContext.jsx';
import CarCard from '../components/CarCard.jsx';
import StatusBadge from '../components/StatusBadge.jsx';
import BookingReceiptModal from '../components/BookingReceiptModal.jsx';
import { formatINR } from '../utils/pricing.js';
import { apiRequest } from '../services/api.js';

export default function Dashboard() {
  const { user, isAuthenticated, isAdmin, updateProfile, logout } = useAuth();
  const { cars, favoriteCars } = useCars();
  const { bookings, cancelBooking } = useBookings();

  const [tab, setTab] = useState('upcoming');
  const [selectedReceiptRef, setSelectedReceiptRef] = useState(null);

  // Review modal state
  const [reviewBooking, setReviewBooking] = useState(null);
  const [ratingVal, setRatingVal] = useState(5);
  const [reviewTitle, setReviewTitle] = useState('');
  const [reviewComment, setReviewComment] = useState('');
  const [submittingReview, setSubmittingReview] = useState(false);

  // Notifications state
  const [notifications, setNotifications] = useState([]);
  const [loadingNotifs, setLoadingNotifs] = useState(false);

  const [profile, setProfile] = useState({
    fullName: user?.fullName || '',
    phone: user?.phone || '',
    license: user?.license || '',
  });
  const [savingProfile, setSavingProfile] = useState(false);

  // Fetch notifications
  const loadNotifications = async () => {
    if (!isAuthenticated) return;
    setLoadingNotifs(true);
    try {
      const res = await apiRequest('/notifications');
      setNotifications(res.notifications || []);
    } catch {
      // offline fallback
    } finally {
      setLoadingNotifs(false);
    }
  };

  useEffect(() => {
    if (isAuthenticated) {
      loadNotifications();
    }
  }, [isAuthenticated]);

  const markNotifRead = async (id) => {
    try {
      await apiRequest(`/notifications/${id}/read`, { method: 'PATCH' });
      setNotifications((prev) => prev.map((n) => (n.id === id ? { ...n, read: true } : n)));
    } catch {
      // ignore
    }
  };

  const myBookings = useMemo(() => {
    if (!user) return [];
    return bookings.filter(
      (b) =>
        b.userId === user.id ||
        b.customer?.email?.toLowerCase() === user.email.toLowerCase()
    );
  }, [bookings, user]);

  const upcomingBookings = useMemo(() => {
    return myBookings.filter((b) => b.status === 'Confirmed');
  }, [myBookings]);

  const pastBookings = useMemo(() => {
    return myBookings.filter((b) => b.status === 'Completed' || b.status === 'Cancelled');
  }, [myBookings]);

  const stats = useMemo(() => {
    const totalSpent = myBookings
      .filter((b) => b.status !== 'Cancelled')
      .reduce((sum, b) => sum + (b.pricing?.total || 0), 0);
    return {
      totalBookings: myBookings.length,
      upcomingCount: upcomingBookings.length,
      favoritesCount: favoriteCars.length,
      totalSpent,
      unreadNotifs: notifications.filter((n) => !n.read).length,
    };
  }, [myBookings, upcomingBookings, favoriteCars, notifications]);

  if (!isAuthenticated) {
    return (
      <div className="container-x py-16">
        <div className="mx-auto max-w-xl rounded-3xl border border-neutral-200 bg-white p-8 text-center shadow-card">
          <span className="mx-auto grid h-14 w-14 place-items-center rounded-2xl bg-accent-soft text-accent">
            <User size={26} />
          </span>
          <h1 className="mt-4 text-2xl font-extrabold">Sign in to view your dashboard</h1>
          <p className="mt-2 text-sm text-neutral-600">
            Track your car bookings, download tax invoices, manage saved favorites, and keep your driver profile ready.
          </p>
          <div className="mt-6 flex flex-wrap justify-center gap-3">
            <Link to="/login" className="btn-primary">Log in</Link>
            <Link to="/register" className="btn-outline">Create account</Link>
          </div>
        </div>
      </div>
    );
  }

  const handleProfileSave = async (e) => {
    e.preventDefault();
    if (!profile.fullName.trim() || profile.fullName.trim().length < 3) {
      toast.error('Full name must be at least 3 characters');
      return;
    }
    setSavingProfile(true);
    try {
      await updateProfile(profile);
      toast.success('Profile updated');
    } catch (err) {
      toast.error(err.message || 'Could not update profile');
    } finally {
      setSavingProfile(false);
    }
  };

  const handleCancelBooking = async (ref, startTime) => {
    const diffHours = (new Date(startTime) - new Date()) / (1000 * 60 * 60);
    if (diffHours < 24) {
      toast.error('Bookings can only be cancelled up to 24 hours prior to pickup.');
      return;
    }
    if (!window.confirm(`Are you sure you want to cancel booking ${ref}? Any prepaid charges will be refunded.`)) return;

    const res = await cancelBooking(ref);
    if (res.ok) {
      toast.success(`Booking ${ref} cancelled successfully`);
      loadNotifications();
    } else {
      toast.error(res.error || 'Could not cancel booking');
    }
  };

  const handleSubmitReview = async (e) => {
    e.preventDefault();
    if (!reviewComment.trim() || reviewComment.trim().length < 5) {
      toast.error('Please write at least 5 characters for your review');
      return;
    }
    setSubmittingReview(true);
    try {
      await apiRequest('/reviews', {
        method: 'POST',
        body: {
          bookingRef: reviewBooking.ref,
          rating: Number(ratingVal),
          title: reviewTitle.trim(),
          comment: reviewComment.trim(),
        },
      });
      toast.success('Thank you for submitting your verified review!');
      setReviewBooking(null);
      setReviewComment('');
      setReviewTitle('');
    } catch (err) {
      toast.error(err.message || 'Could not submit review');
    } finally {
      setSubmittingReview(false);
    }
  };

  return (
    <div className="container-x py-10">
      {/* Top Header */}
      <div className="flex flex-wrap items-center justify-between gap-4 border-b border-neutral-200 pb-6">
        <div>
          <div className="flex items-center gap-2">
            <h1 className="heading">Welcome, {user.fullName}</h1>
            {isAdmin && (
              <span className="inline-flex items-center gap-1 rounded-full bg-ink px-3 py-1 text-xs font-bold text-white">
                <Shield size={12} /> Admin
              </span>
            )}
          </div>
          <p className="mt-1 text-sm text-neutral-600">
            {user.email} · Driver Profile & Booking Management Portal
          </p>
        </div>

        <div className="flex flex-wrap items-center gap-2">
          {isAdmin && (
            <Link to="/admin" className="btn-dark text-xs flex items-center gap-1.5">
              <Shield size={14} /> Admin Portal
            </Link>
          )}
          <Link to="/cars" className="btn-primary text-xs">Book a car</Link>
          <button onClick={logout} className="btn-outline text-xs flex items-center gap-1.5">
            <LogOut size={14} /> Log out
          </button>
        </div>
      </div>

      {/* Stat Cards */}
      <div className="mt-8 grid gap-4 sm:grid-cols-2 lg:grid-cols-4">
        <div className="rounded-3xl border border-neutral-200 bg-white p-5 shadow-card">
          <div className="flex items-center justify-between text-neutral-500">
            <span className="text-xs font-bold uppercase tracking-wider">Upcoming Trips</span>
            <CalendarCheck size={18} className="text-accent" />
          </div>
          <p className="mt-3 text-3xl font-extrabold">{stats.upcomingCount}</p>
        </div>

        <div className="rounded-3xl border border-neutral-200 bg-white p-5 shadow-card">
          <div className="flex items-center justify-between text-neutral-500">
            <span className="text-xs font-bold uppercase tracking-wider">Total Bookings</span>
            <Car size={18} className="text-green-600" />
          </div>
          <p className="mt-3 text-3xl font-extrabold">{stats.totalBookings}</p>
        </div>

        <div className="rounded-3xl border border-neutral-200 bg-white p-5 shadow-card">
          <div className="flex items-center justify-between text-neutral-500">
            <span className="text-xs font-bold uppercase tracking-wider">Saved Cars</span>
            <Heart size={18} className="text-red-500" />
          </div>
          <p className="mt-3 text-3xl font-extrabold">{stats.favoritesCount}</p>
        </div>

        <div className="rounded-3xl border border-neutral-200 bg-white p-5 shadow-card">
          <div className="flex items-center justify-between text-neutral-500">
            <span className="text-xs font-bold uppercase tracking-wider">Total Rental Spend</span>
            <IndianRupee size={18} className="text-accent" />
          </div>
          <p className="mt-3 text-3xl font-extrabold">{formatINR(stats.totalSpent)}</p>
        </div>
      </div>

      {/* Tabs */}
      <div className="mt-8 flex flex-wrap gap-2 border-b border-neutral-200 pb-4">
        {[
          ['upcoming', `Upcoming Trips (${upcomingBookings.length})`],
          ['history', `Past Trips (${pastBookings.length})`],
          ['favorites', `Favorites (${favoriteCars.length})`],
          ['notifications', `Alerts (${notifications.length})`],
          ['profile', 'Profile Settings'],
        ].map(([key, label]) => (
          <button
            key={key}
            onClick={() => setTab(key)}
            className={`rounded-full px-4 py-2 text-sm font-semibold transition ${
              tab === key ? 'bg-ink text-white' : 'bg-neutral-100 text-neutral-600 hover:bg-neutral-200'
            }`}
          >
            {label}
          </button>
        ))}
      </div>

      {/* TAB 1: UPCOMING TRIPS */}
      {tab === 'upcoming' && (
        <div className="mt-6 space-y-4">
          {upcomingBookings.length === 0 ? (
            <div className="rounded-3xl border border-dashed border-neutral-300 py-16 text-center bg-white p-8">
              <CalendarCheck size={36} className="mx-auto text-neutral-400" />
              <h2 className="mt-3 font-bold text-lg text-ink">No upcoming trips scheduled</h2>
              <p className="mt-1 text-sm text-neutral-600">Choose from 100+ verified vehicles and book your next highway escape.</p>
              <Link to="/cars" className="btn-dark mt-5 inline-flex items-center gap-1.5">
                Explore Available Cars <ArrowRight size={15} />
              </Link>
            </div>
          ) : (
            <div className="space-y-4">
              {upcomingBookings.map((b) => {
                const canCancel = (new Date(b.start) - new Date()) / (1000 * 60 * 60) >= 24;
                return (
                  <div key={b.ref} className="rounded-3xl border border-neutral-200 bg-white p-6 shadow-card transition hover:border-neutral-300">
                    <div className="flex flex-col sm:flex-row sm:items-start sm:justify-between gap-4 border-b border-neutral-100 pb-4">
                      <div>
                        <div className="flex items-center gap-2">
                          <span className="font-mono text-xs font-bold bg-neutral-100 px-2.5 py-1 rounded-md text-ink">
                            {b.ref}
                          </span>
                          <StatusBadge status={b.status} />
                          <span className={`text-xs font-bold ${b.paymentStatus === 'Paid' ? 'text-green-700' : 'text-amber-700'}`}>
                            Payment: {b.paymentStatus}
                          </span>
                        </div>
                        <h3 className="mt-2 text-xl font-black text-ink">{b.car?.brand} {b.car?.model}</h3>
                        <p className="text-xs text-neutral-500">{b.car?.category} · Pickup from {b.pickup}</p>
                      </div>

                      <div className="text-left sm:text-right">
                        <p className="font-mono text-xl font-black text-ink">{formatINR(b.pricing?.total || 0)}</p>
                        <p className="text-xs text-neutral-400">{b.pricing?.days || 1} day(s) duration</p>
                      </div>
                    </div>

                    <div className="mt-4 grid grid-cols-1 sm:grid-cols-2 gap-4 text-xs">
                      <div>
                        <span className="text-neutral-400 block font-semibold uppercase tracking-wider">Pickup Schedule</span>
                        <p className="font-bold text-ink mt-0.5">
                          {new Date(b.start).toLocaleString('en-IN', { dateStyle: 'medium', timeStyle: 'short' })}
                        </p>
                        <p className="text-neutral-500 mt-0.5">{b.pickup}</p>
                      </div>
                      <div>
                        <span className="text-neutral-400 block font-semibold uppercase tracking-wider">Return Schedule</span>
                        <p className="font-bold text-ink mt-0.5">
                          {new Date(b.end).toLocaleString('en-IN', { dateStyle: 'medium', timeStyle: 'short' })}
                        </p>
                        <p className="text-neutral-500 mt-0.5">{b.dropoff}</p>
                      </div>
                    </div>

                    <div className="mt-5 flex flex-wrap items-center justify-between gap-3 border-t border-neutral-100 pt-4">
                      <div className="text-xs text-neutral-500">
                        {canCancel ? (
                          <span className="text-green-700 font-semibold">Free cancellation eligible (24+ hours before pickup)</span>
                        ) : (
                          <span className="text-neutral-400">Cancellation closed (&lt; 24h to pickup)</span>
                        )}
                      </div>

                      <div className="flex items-center gap-2">
                        <button
                          onClick={() => setSelectedReceiptRef(b.ref)}
                          className="btn-outline text-xs px-3 py-1.5 flex items-center gap-1.5"
                        >
                          <FileText size={14} /> Download Receipt
                        </button>

                        {canCancel && (
                          <button
                            onClick={() => handleCancelBooking(b.ref, b.start)}
                            className="rounded-xl border border-red-200 px-3 py-1.5 text-xs font-bold text-red-600 hover:bg-red-50"
                          >
                            Cancel Booking
                          </button>
                        )}
                      </div>
                    </div>
                  </div>
                );
              })}
            </div>
          )}
        </div>
      )}

      {/* TAB 2: TRIP HISTORY */}
      {tab === 'history' && (
        <div className="mt-6 space-y-4">
          {pastBookings.length === 0 ? (
            <div className="rounded-3xl border border-dashed border-neutral-300 py-16 text-center bg-white p-8">
              <Clock size={36} className="mx-auto text-neutral-400" />
              <h2 className="mt-3 font-bold text-lg text-ink">No completed or cancelled trips yet</h2>
              <p className="mt-1 text-sm text-neutral-600">Past booking receipts and trip history will appear here.</p>
            </div>
          ) : (
            <div className="space-y-4">
              {pastBookings.map((b) => (
                <div key={b.ref} className="rounded-3xl border border-neutral-200 bg-white p-6 shadow-card">
                  <div className="flex flex-col sm:flex-row sm:items-start sm:justify-between gap-4 border-b border-neutral-100 pb-4">
                    <div>
                      <div className="flex items-center gap-2">
                        <span className="font-mono text-xs font-bold bg-neutral-100 px-2 py-0.5 rounded text-ink">{b.ref}</span>
                        <StatusBadge status={b.status} />
                      </div>
                      <h3 className="mt-2 font-extrabold text-lg text-ink">{b.car?.brand} {b.car?.model}</h3>
                      <p className="text-xs text-neutral-500">
                        {new Date(b.start).toLocaleDateString('en-IN', { month: 'short', day: 'numeric', year: 'numeric' })} — {b.pickup}
                      </p>
                    </div>

                    <div className="sm:text-right">
                      <p className="font-mono font-bold text-ink">{formatINR(b.pricing?.total || 0)}</p>
                      <button
                        onClick={() => setSelectedReceiptRef(b.ref)}
                        className="mt-2 btn-outline text-xs px-2.5 py-1 flex items-center gap-1 sm:ml-auto"
                      >
                        <FileText size={13} /> View Receipt
                      </button>
                    </div>
                  </div>

                  {b.status === 'Completed' && (
                    <div className="mt-4 flex items-center justify-between text-xs">
                      <span className="text-neutral-500">Trip completed · Thank you for driving with Drivo!</span>
                      <button
                        onClick={() => setReviewBooking(b)}
                        className="btn-dark text-xs px-3 py-1.5 flex items-center gap-1"
                      >
                        <Star size={13} className="fill-amber-400 text-amber-400" /> Leave a Review
                      </button>
                    </div>
                  )}
                </div>
              ))}
            </div>
          )}
        </div>
      )}

      {/* TAB 3: FAVORITES */}
      {tab === 'favorites' && (
        <div className="mt-6">
          {favoriteCars.length === 0 ? (
            <div className="rounded-3xl border border-dashed border-neutral-300 py-16 text-center bg-white p-8">
              <Heart size={36} className="mx-auto text-neutral-400" />
              <h2 className="mt-3 font-bold text-lg text-ink">No favorite cars saved</h2>
              <p className="mt-1 text-sm text-neutral-600">Click the heart icon on any car card to save it for quick booking.</p>
              <Link to="/cars" className="btn-dark mt-5 inline-block">Explore Fleet</Link>
            </div>
          ) : (
            <div className="grid gap-6 sm:grid-cols-2 lg:grid-cols-3">
              {favoriteCars.map((c) => <CarCard key={c.id} car={c} />)}
            </div>
          )}
        </div>
      )}

      {/* TAB 4: NOTIFICATIONS */}
      {tab === 'notifications' && (
        <div className="mt-6 space-y-4">
          {notifications.length === 0 ? (
            <div className="rounded-3xl border border-dashed border-neutral-300 py-16 text-center bg-white p-8">
              <Bell size={36} className="mx-auto text-neutral-400" />
              <h2 className="mt-3 font-bold text-lg text-ink">No notifications yet</h2>
              <p className="mt-1 text-sm text-neutral-600">Trip updates, booking receipts, and policy notices will be delivered here.</p>
            </div>
          ) : (
            <div className="space-y-3">
              {notifications.map((n) => (
                <div
                  key={n.id}
                  onClick={() => !n.read && markNotifRead(n.id)}
                  className={`cursor-pointer rounded-2xl border p-4 transition ${
                    n.read ? 'border-neutral-200 bg-white' : 'border-accent/40 bg-accent-soft/30'
                  }`}
                >
                  <div className="flex items-start justify-between gap-3">
                    <div>
                      <div className="flex items-center gap-2">
                        {!n.read && <span className="h-2 w-2 rounded-full bg-accent" />}
                        <h4 className="font-bold text-sm text-ink">{n.title}</h4>
                      </div>
                      <p className="mt-1 text-xs text-neutral-600">{n.message}</p>
                    </div>
                    <span className="font-mono text-[10px] text-neutral-400 whitespace-nowrap">
                      {new Date(n.createdAt).toLocaleDateString('en-IN', { month: 'short', day: 'numeric' })}
                    </span>
                  </div>
                </div>
              ))}
            </div>
          )}
        </div>
      )}

      {/* TAB 5: PROFILE SETTINGS */}
      {tab === 'profile' && (
        <div className="mt-6">
          <form onSubmit={handleProfileSave} className="max-w-xl rounded-3xl border border-neutral-200 bg-white p-6 shadow-card space-y-4">
            <h2 className="text-lg font-bold">Driver Profile Settings</h2>
            <p className="text-xs text-neutral-500">Ensure your driving licence number is up-to-date for fast-track vehicle handover.</p>

            <div>
              <label htmlFor="prof-name" className="mb-1 block text-xs font-semibold text-neutral-600">Full Name</label>
              <input id="prof-name" className="field" value={profile.fullName} onChange={(e) => setProfile((p) => ({ ...p, fullName: e.target.value }))} />
            </div>

            <div>
              <label htmlFor="prof-email" className="mb-1 block text-xs font-semibold text-neutral-600">Email Address (account login)</label>
              <input id="prof-email" className="field bg-neutral-100 text-neutral-500" value={user.email} disabled />
            </div>

            <div className="grid gap-4 sm:grid-cols-2">
              <div>
                <label htmlFor="prof-phone" className="mb-1 block text-xs font-semibold text-neutral-600">Mobile Number</label>
                <input id="prof-phone" className="field" value={profile.phone} onChange={(e) => setProfile((p) => ({ ...p, phone: e.target.value }))} placeholder="+91 98765 43210" />
              </div>
              <div>
                <label htmlFor="prof-lic" className="mb-1 block text-xs font-semibold text-neutral-600">Driving Licence Number</label>
                <input id="prof-lic" className="field uppercase" value={profile.license} onChange={(e) => setProfile((p) => ({ ...p, license: e.target.value }))} placeholder="TN37 20190012345" />
              </div>
            </div>

            <button type="submit" disabled={savingProfile} className="btn-dark text-xs mt-2">
              {savingProfile ? 'Saving...' : 'Save Profile Changes'}
            </button>
          </form>
        </div>
      )}

      {/* REVIEW SUBMISSION MODAL */}
      {reviewBooking && (
        <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/60 p-4 backdrop-blur-sm">
          <div className="relative w-full max-w-lg rounded-3xl bg-white p-6 shadow-2xl">
            <h3 className="text-lg font-black text-ink">Rate & Review Your Trip</h3>
            <p className="text-xs text-neutral-500 mt-1">
              Vehicle: {reviewBooking.car?.brand} {reviewBooking.car?.model} (Ref: {reviewBooking.ref})
            </p>

            <form onSubmit={handleSubmitReview} className="mt-5 space-y-4">
              <div>
                <label className="block text-xs font-bold text-neutral-600 mb-1">Rating</label>
                <div className="flex gap-2">
                  {[1, 2, 3, 4, 5].map((star) => (
                    <button
                      type="button"
                      key={star}
                      onClick={() => setRatingVal(star)}
                      className="p-1 text-amber-400 hover:scale-110 transition"
                    >
                      <Star size={24} className={star <= ratingVal ? 'fill-amber-400' : 'text-neutral-300'} />
                    </button>
                  ))}
                  <span className="ml-2 self-center text-sm font-bold text-ink">{ratingVal} / 5 Stars</span>
                </div>
              </div>

              <div>
                <label className="block text-xs font-bold text-neutral-600 mb-1">Review Headline (optional)</label>
                <input
                  type="text"
                  placeholder="e.g. Great condition, smooth highway ride!"
                  value={reviewTitle}
                  onChange={(e) => setReviewTitle(e.target.value)}
                  className="field text-xs"
                />
              </div>

              <div>
                <label className="block text-xs font-bold text-neutral-600 mb-1">Your Detailed Experience</label>
                <textarea
                  required
                  rows={4}
                  placeholder="Tell other drivers about car cleanliness, pickup experience, and fuel economy..."
                  value={reviewComment}
                  onChange={(e) => setReviewComment(e.target.value)}
                  className="field text-xs resize-none"
                />
              </div>

              <div className="flex justify-end gap-2 pt-2 border-t border-neutral-100">
                <button
                  type="button"
                  onClick={() => setReviewBooking(null)}
                  className="btn-outline text-xs"
                >
                  Cancel
                </button>
                <button
                  type="submit"
                  disabled={submittingReview}
                  className="btn-dark text-xs"
                >
                  {submittingReview ? 'Submitting...' : 'Submit Verified Review'}
                </button>
              </div>
            </form>
          </div>
        </div>
      )}

      {/* RECEIPT / INVOICE MODAL */}
      {selectedReceiptRef && (
        <BookingReceiptModal bookingRef={selectedReceiptRef} onClose={() => setSelectedReceiptRef(null)} />
      )}
    </div>
  );
}
