import { useEffect, useState } from 'react';
import { Link, useParams } from 'react-router-dom';
import { CheckCircle2, Info, FileText, ArrowRight } from 'lucide-react';
import { useBookings } from '../context/BookingContext.jsx';
import BookingSummary from '../components/BookingSummary.jsx';
import StatusBadge from '../components/StatusBadge.jsx';
import BookingReceiptModal from '../components/BookingReceiptModal.jsx';
import { apiRequest } from '../services/api.js';

export default function BookingConfirmation() {
  const { ref } = useParams();
  const { getBooking } = useBookings();
  const [b, setB] = useState(() => getBooking(ref));
  const [loading, setLoading] = useState(!b);
  const [showReceipt, setShowReceipt] = useState(false);

  useEffect(() => {
    if (!b && ref) {
      setLoading(true);
      apiRequest(`/bookings/${ref}`)
        .then((data) => setB(data.booking))
        .catch(() => setB(null))
        .finally(() => setLoading(false));
    }
  }, [ref, b]);

  if (loading) {
    return (
      <div className="container-x py-20 text-center">
        <div className="mx-auto h-8 w-8 animate-spin rounded-full border-2 border-ink border-t-transparent" />
        <p className="mt-3 text-sm text-neutral-500">Loading booking confirmation...</p>
      </div>
    );
  }

  if (!b) {
    return (
      <section className="container-x grid min-h-[60vh] place-items-center py-20 text-center">
        <div>
          <h1 className="heading">Booking not found</h1>
          <p className="mt-3 text-neutral-600">No booking with reference {ref} exists.</p>
          <Link to="/cars" className="btn-dark mt-6 inline-block">Browse cars</Link>
        </div>
      </section>
    );
  }

  return (
    <div className="container-x max-w-3xl py-10">
      <div className="rounded-3xl bg-green-50 p-6 text-center border border-green-200">
        <CheckCircle2 size={44} className="mx-auto text-green-600" />
        <h1 className="mt-3 text-2xl font-black text-ink">Booking Confirmed!</h1>
        <p className="mt-1 text-sm text-neutral-700">
          Booking Reference: <strong className="font-mono text-base">{b.ref}</strong>
        </p>
        <div className="mt-3 flex flex-wrap justify-center items-center gap-2 text-xs">
          <span>Booking Status: <StatusBadge status={b.status} /></span>
          <span className="mx-1 text-neutral-300">•</span>
          <span>Payment Status: <StatusBadge status={b.paymentStatus} /></span>
        </div>
      </div>

      <div className="mt-6">
        <BookingSummary
          car={b.car}
          start={b.start}
          end={b.end}
          pickup={b.pickup}
          dropoff={b.dropoff}
          extras={b.extras}
          pricing={b.pricing}
          title="Reservation Details"
        />
      </div>

      <div className="mt-4 rounded-2xl bg-neutral-50 p-4 border border-neutral-200 text-xs text-neutral-600 flex flex-col sm:flex-row sm:items-center sm:justify-between gap-3">
        <div>
          <p className="font-semibold text-ink">Official Tax Invoice & Rental Receipt Ready</p>
          <p className="text-neutral-500 mt-0.5">Booking persisted in MySQL database. Includes itemized GST and schedule breakdown.</p>
        </div>
        <button
          onClick={() => setShowReceipt(true)}
          className="btn-outline shrink-0 text-xs flex items-center gap-1.5 px-3 py-2"
        >
          <FileText size={15} /> Download Tax Invoice
        </button>
      </div>

      <div className="mt-6 flex flex-wrap gap-3">
        {b.paymentStatus !== 'Paid' && (
          <Link to={`/payment?ref=${b.ref}`} className="btn-primary">
            Continue to payment
          </Link>
        )}
        <Link to="/dashboard" className="btn-outline">
          My dashboard
        </Link>
        <Link to="/cars" className="btn-outline">
          Browse more cars
        </Link>
      </div>

      {showReceipt && (
        <BookingReceiptModal bookingRef={b.ref} onClose={() => setShowReceipt(false)} />
      )}
    </div>
  );
}
