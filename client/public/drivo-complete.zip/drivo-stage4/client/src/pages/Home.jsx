import { useState, useRef } from 'react';
import { Link, useNavigate } from 'react-router-dom';
import { ChevronDown, Quote, Tag, ArrowRight, Sparkles, ShieldCheck, Zap, Star } from 'lucide-react';
import toast from 'react-hot-toast';
import SearchBar from '../components/SearchBar.jsx';
import CarCard from '../components/CarCard.jsx';
import CarImage from '../components/CarImage.jsx';
import { useCars } from '../context/CarContext.jsx';
import { categories, steps, benefits, offers, testimonials, faqs } from '../data/homeContent.js';

const HERO_POSTER = 'https://images.unsplash.com/photo-1492144534655-ae79c964c9d7?auto=format&fit=crop&w=1920&q=80';
const HERO_VIDEO = '/hero-drive.mp4';
const FALLBACK_ONLINE_VIDEO = 'https://assets.mixkit.co/videos/41549/41549-720.mp4';

function SectionHead({ title, text, badge }) {
  return (
    <div className="mb-12 max-w-2xl">
      {badge && (
        <span className="inline-flex items-center gap-1.5 rounded-full bg-accent-soft px-3.5 py-1 text-xs font-bold text-accent uppercase tracking-wider mb-3">
          <Sparkles size={13} /> {badge}
        </span>
      )}
      <h2 className="heading">{title}</h2>
      {text && <p className="mt-3 text-lg text-neutral-600 leading-relaxed">{text}</p>}
    </div>
  );
}

function Faq() {
  const [open, setOpen] = useState(0);
  return (
    <div className="divide-y divide-neutral-200 rounded-3xl border border-neutral-200 bg-white shadow-card">
      {faqs.map((f, i) => (
        <div key={f.q}>
          <button
            onClick={() => setOpen(open === i ? -1 : i)}
            aria-expanded={open === i}
            className="flex w-full items-center justify-between gap-4 px-6 py-5 text-left font-bold text-neutral-900 transition hover:text-accent"
          >
            {f.q}
            <ChevronDown size={18} className={`shrink-0 transition-transform duration-300 ${open === i ? 'rotate-180 text-accent' : 'text-neutral-400'}`} />
          </button>
          {open === i && <p className="px-6 pb-5 text-sm leading-relaxed text-neutral-600">{f.a}</p>}
        </div>
      ))}
    </div>
  );
}

function Newsletter() {
  const [email, setEmail] = useState('');
  const [error, setError] = useState('');
  const submit = (e) => {
    e.preventDefault();
    if (!/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(email)) {
      setError('Enter a valid email address');
      return;
    }
    setError('');
    toast.success('Subscribed! Special deals will arrive in your inbox.');
    setEmail('');
  };
  return (
    <form onSubmit={submit} noValidate className="mt-6 flex w-full max-w-md flex-col gap-2 sm:flex-row">
      <div className="flex-1">
        <label htmlFor="newsletter" className="sr-only">Email address</label>
        <input
          id="newsletter"
          type="email"
          value={email}
          onChange={(e) => setEmail(e.target.value)}
          placeholder="you@example.com"
          className="field border-white/30 bg-white/10 text-white placeholder:text-neutral-300 focus:bg-white/20"
        />
        {error && <p className="mt-1 text-xs font-semibold text-white">{error}</p>}
      </div>
      <button className="btn bg-white font-bold text-ink hover:bg-neutral-100 shadow-lg">Subscribe</button>
    </form>
  );
}

export default function Home() {
  const navigate = useNavigate();
  const { cars } = useCars();
  const [videoLoaded, setVideoLoaded] = useState(false);
  const [selectedCategoryTab, setSelectedCategoryTab] = useState('All');
  const videoRef = useRef(null);

  // Show up to 8 top-rated vehicles on the homepage
  const featured = [...cars].sort((a, b) => b.rating - a.rating || b.popularity - a.popularity).slice(0, 8);

  const filteredByTab = selectedCategoryTab === 'All'
    ? featured
    : cars.filter((c) => c.category === selectedCategoryTab);

  const copyCode = async (code) => {
    try {
      await navigator.clipboard.writeText(code);
      toast.success(`${code} copied to clipboard!`);
    } catch {
      toast(`Use promo code ${code} at checkout`);
    }
  };

  return (
    <>
      {/* 2027 Cinematic Hero Video Section */}
      <section className="relative min-h-[92vh] flex items-center justify-center overflow-hidden bg-ink text-white">
        {/* HTML5 Background Video with Poster Fallback */}
        <div className="absolute inset-0 w-full h-full overflow-hidden">
          <video
            ref={videoRef}
            autoPlay
            loop
            muted
            playsInline
            poster={HERO_POSTER}
            onCanPlay={() => setVideoLoaded(true)}
            className={`absolute top-1/2 left-1/2 min-w-full min-h-full -translate-x-1/2 -translate-y-1/2 object-cover transition-opacity duration-1000 ${
              videoLoaded ? 'opacity-55' : 'opacity-0'
            }`}
          >
            <source src={HERO_VIDEO} type="video/mp4" />
            <source src={FALLBACK_ONLINE_VIDEO} type="video/mp4" />
          </video>

          {/* Fallback Static Poster Image when Video is loading or motion is reduced */}
          <div
            className={`absolute inset-0 bg-cover bg-center transition-opacity duration-1000 ${
              videoLoaded ? 'opacity-0 pointer-events-none' : 'opacity-60'
            }`}
            style={{ backgroundImage: `url(${HERO_POSTER})` }}
          />

          {/* High-end 2027 Dark Vignette & Mesh Gradient Overlay */}
          <div className="absolute inset-0 bg-gradient-to-t from-ink via-ink/65 to-ink/40" />
          <div className="absolute inset-0 bg-[radial-gradient(ellipse_at_top,_var(--tw-gradient-stops))] from-accent/20 via-transparent to-transparent opacity-70" />
        </div>

        {/* Hero Content */}
        <div className="container-x relative z-10 pt-20 pb-24 sm:pt-28 sm:pb-32 flex flex-col items-center text-center">
          {/* Subtle Tagline Badge */}
          <div className="animate-entrance-1 inline-flex items-center gap-2 rounded-full border border-white/20 bg-white/10 px-4 py-1.5 text-xs font-bold uppercase tracking-wider backdrop-blur-md mb-6">
            <span className="h-2 w-2 rounded-full bg-accent animate-ping" />
            Next-Gen Car Rentals • Premium 2027 Fleet
          </div>

          <h1 className="animate-entrance-1 max-w-4xl text-5xl font-black leading-[1.05] tracking-tight sm:text-7xl lg:text-8xl drop-shadow-sm">
            Your Journey. <span className="bg-gradient-to-r from-white via-neutral-100 to-accent text-transparent bg-clip-text">Your Rules.</span>
          </h1>

          <p className="animate-entrance-2 mt-6 max-w-2xl text-lg sm:text-2xl font-normal text-neutral-200 leading-relaxed drop-shadow">
            Discover your perfect drive with Drivo. Hatchbacks, electric cruisers, SUVs, and luxury sedans available for instant pickup.
          </p>

          <div className="animate-entrance-2 mt-8 flex flex-wrap items-center justify-center gap-4">
            <Link to="/cars" className="btn-primary text-base px-8 py-3.5 shadow-2xl">
              Explore Cars <ArrowRight size={18} />
            </Link>
            <a href="#search-section" className="btn-outline text-white border-white/30 hover:border-white text-base px-8 py-3.5">
              Book Your Ride
            </a>
          </div>

          {/* Integrated Search Bar Container with Smooth Entrance */}
          <div id="search-section" className="animate-entrance-3 mt-14 w-full max-w-6xl text-left">
            <SearchBar />
          </div>
        </div>

        {/* Bottom Ambient Glow Border */}
        <div className="absolute bottom-0 left-0 right-0 h-1 bg-gradient-to-r from-transparent via-accent to-transparent opacity-60" />
      </section>

      {/* Popular Categories Grid */}
      <section className="section bg-neutral-50/70 border-b border-neutral-200">
        <div className="container-x">
          <div className="flex flex-col sm:flex-row sm:items-end sm:justify-between gap-4 mb-10">
            <div>
              <span className="text-xs font-bold uppercase tracking-wider text-accent mb-2 block">Choose Your Vibe</span>
              <h2 className="heading">Browse by Category</h2>
              <p className="mt-2 text-neutral-600">Select from our certified collection of premium models.</p>
            </div>
            <Link to="/cars" className="text-sm font-bold text-accent flex items-center gap-1 hover:gap-2 transition-all">
              View all {cars.length} cars <ArrowRight size={16} />
            </Link>
          </div>

          <div className="grid grid-cols-2 gap-4 sm:grid-cols-3 lg:grid-cols-6">
            {categories.map(({ name, icon: Icon, blurb, image }) => {
              const count = cars.filter((c) => c.category === name).length;
              return (
                <button
                  key={name}
                  onClick={() => navigate(`/cars?category=${encodeURIComponent(name)}`)}
                  className="group relative overflow-hidden rounded-3xl border border-neutral-200 bg-white p-4 text-left transition-all duration-300 hover:border-accent hover:shadow-xl hover:-translate-y-1.5"
                >
                  {image && (
                    <div className="mb-3.5 aspect-[16/10] overflow-hidden rounded-2xl bg-neutral-100">
                      <CarImage
                        src={image}
                        alt={`${name} car category`}
                        className="h-full w-full object-cover transition duration-500 group-hover:scale-110"
                      />
                    </div>
                  )}
                  <div className="flex items-center justify-between gap-1">
                    <div className="flex items-center gap-2">
                      <span className="grid h-8 w-8 place-items-center rounded-xl bg-neutral-100 text-ink group-hover:bg-accent group-hover:text-white transition duration-300">
                        <Icon size={16} />
                      </span>
                      <p className="font-extrabold text-sm">{name}</p>
                    </div>
                  </div>
                  <div className="mt-2 flex items-center justify-between text-xs text-neutral-500">
                    <span className="line-clamp-1">{blurb}</span>
                    {count > 0 && (
                      <span className="ml-1 shrink-0 rounded-full bg-neutral-100 px-2 py-0.5 text-[10px] font-bold text-ink">
                        {count} cars
                      </span>
                    )}
                  </div>
                </button>
              );
            })}
          </div>
        </div>
      </section>

      {/* Featured Fleet (Up to 100+ vehicles available) */}
      <section className="section">
        <div className="container-x">
          <div className="flex flex-col lg:flex-row lg:items-end lg:justify-between gap-6 mb-10">
            <SectionHead
              badge="Fleet Highlights"
              title="Featured Vehicles"
              text="Meticulously inspected, washed, and sanitised before every key handover."
            />

            {/* Category Filter Pills */}
            <div className="flex flex-wrap gap-2 self-start lg:self-center">
              {['All', 'SUV', 'Sedan', 'Hatchback', 'MUV / MPV', 'Luxury', 'Electric Vehicles'].map((tab) => (
                <button
                  key={tab}
                  onClick={() => setSelectedCategoryTab(tab)}
                  className={`rounded-full px-4 py-2 text-xs font-bold transition-all duration-200 ${
                    selectedCategoryTab === tab
                      ? 'bg-ink text-white shadow-md'
                      : 'bg-neutral-100 text-neutral-600 hover:bg-neutral-200'
                  }`}
                >
                  {tab}
                </button>
              ))}
            </div>
          </div>

          <div className="grid gap-6 sm:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4">
            {filteredByTab.slice(0, 8).map((c) => (
              <CarCard key={c.id} car={c} />
            ))}
          </div>

          <div className="mt-12 text-center">
            <Link to="/cars" className="btn-dark px-8 py-3.5 text-base">
              Explore All {cars.length} Cars in Fleet <ArrowRight size={16} />
            </Link>
          </div>
        </div>
      </section>

      {/* Why Choose Drivo (2027 Value Pillars) */}
      <section className="section bg-ink text-white relative overflow-hidden">
        {/* Subtle background glow */}
        <div className="absolute top-0 right-1/4 h-96 w-96 rounded-full bg-accent/15 blur-3xl pointer-events-none" />

        <div className="container-x relative z-10">
          <SectionHead
            badge="The Drivo Advantage"
            title="Engineered for Peace of Mind"
            text="Transparent rates, zero security deposit hassles, and round-the-clock roadside cover."
          />

          <div className="grid gap-6 sm:grid-cols-2 lg:grid-cols-4">
            {benefits.map(({ icon: Icon, title, text }) => (
              <div
                key={title}
                className="group rounded-3xl border border-white/10 bg-white/5 p-7 backdrop-blur transition-all duration-300 hover:border-accent hover:bg-white/10 hover:-translate-y-1"
              >
                <span className="grid h-12 w-12 place-items-center rounded-2xl bg-accent/20 text-accent group-hover:scale-110 transition duration-300">
                  <Icon size={24} />
                </span>
                <h3 className="mt-5 text-xl font-bold">{title}</h3>
                <p className="mt-2 text-sm leading-relaxed text-neutral-400">{text}</p>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* How it works */}
      <section className="section bg-neutral-50/70 border-b border-neutral-200">
        <div className="container-x">
          <SectionHead
            badge="Fast & Simple"
            title="How It Works"
            text="Three effortless steps from search to sliding behind the steering wheel."
          />
          <ol className="grid gap-6 md:grid-cols-3">
            {steps.map(({ icon: Icon, title, text }, i) => (
              <li
                key={title}
                className="group relative rounded-3xl border border-neutral-200 bg-white p-7 shadow-card transition duration-300 hover:border-ink hover:-translate-y-1"
              >
                <div className="flex items-center justify-between">
                  <span className="grid h-12 w-12 place-items-center rounded-2xl bg-accent-soft text-accent group-hover:bg-ink group-hover:text-white transition duration-300">
                    <Icon size={24} />
                  </span>
                  <span className="font-mono text-sm font-extrabold text-neutral-400">0{i + 1}</span>
                </div>
                <h3 className="mt-5 text-xl font-bold">{title}</h3>
                <p className="mt-2 text-sm leading-relaxed text-neutral-600">{text}</p>
              </li>
            ))}
          </ol>
        </div>
      </section>

      {/* Special Offers & Promo Codes */}
      <section className="section">
        <div className="container-x">
          <SectionHead
            badge="Exclusive Coupons"
            title="Promotions & Instant Savings"
            text="Tap any coupon code to copy and apply directly at payment checkout."
          />
          <div className="grid gap-6 md:grid-cols-3">
            {offers.map((o) => (
              <div
                key={o.code}
                className="group flex flex-col rounded-3xl border-2 border-dashed border-neutral-300 bg-white p-7 transition duration-300 hover:border-accent hover:shadow-card"
              >
                <div className="flex items-center justify-between">
                  <span className="grid h-10 w-10 place-items-center rounded-xl bg-accent-soft text-accent">
                    <Tag size={20} />
                  </span>
                  <span className="text-xs font-semibold uppercase tracking-wider text-green-700 bg-green-50 px-2.5 py-1 rounded-full">
                    Active
                  </span>
                </div>
                <h3 className="mt-4 text-xl font-bold">{o.title}</h3>
                <p className="mt-1 flex-1 text-sm text-neutral-600">{o.text}</p>
                <button
                  type="button"
                  onClick={() => copyCode(o.code)}
                  className="btn-outline mt-6 font-mono font-bold tracking-wider self-start group-hover:border-accent group-hover:text-accent"
                >
                  {o.code}
                </button>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* Testimonials */}
      <section className="section bg-neutral-50/70 border-y border-neutral-200">
        <div className="container-x">
          <SectionHead
            badge="Customer Stories"
            title="Loved by Travellers"
            text="Real reviews from drivers who booked with Drivo for vacations and city commutes."
          />
          <div className="grid gap-6 md:grid-cols-3">
            {testimonials.map((t) => (
              <figure key={t.name} className="rounded-3xl border border-neutral-200 bg-white p-7 shadow-card flex flex-col justify-between">
                <div>
                  <div className="flex items-center gap-1 text-amber-400 mb-4">
                    {[1, 2, 3, 4, 5].map((s) => (
                      <Star key={s} size={16} className="fill-amber-400" />
                    ))}
                  </div>
                  <blockquote className="text-sm leading-relaxed text-neutral-700 font-medium">
                    &ldquo;{t.text}&rdquo;
                  </blockquote>
                </div>
                <figcaption className="mt-6 border-t border-neutral-100 pt-4 flex items-center justify-between text-sm">
                  <span className="font-bold text-ink">{t.name}</span>
                  <span className="text-xs text-neutral-500">{t.city}</span>
                </figcaption>
              </figure>
            ))}
          </div>
        </div>
      </section>

      {/* Final Booking Call-To-Action Banner */}
      <section className="section bg-ink text-white relative overflow-hidden">
        <div className="container-x relative z-10 flex flex-col lg:flex-row lg:items-center lg:justify-between gap-8">
          <div className="max-w-2xl">
            <span className="inline-flex items-center gap-1.5 rounded-full bg-accent/20 px-3.5 py-1 text-xs font-bold text-accent uppercase tracking-wider mb-3">
              <Zap size={14} /> Ready for the road?
            </span>
            <h2 className="text-3xl font-black sm:text-5xl tracking-tight leading-tight">
              Unlock Your Next Journey in Under Two Minutes.
            </h2>
            <p className="mt-4 text-neutral-300 text-base sm:text-lg">
              Compare {cars.length} cars across 8 cities with instant confirmation and zero hidden costs.
            </p>
          </div>
          <div className="flex flex-wrap items-center gap-4">
            <Link to="/cars" className="btn-primary text-base px-8 py-3.5 shadow-xl">
              Browse Fleet <ArrowRight size={18} />
            </Link>
            <Link to="/register" className="btn-outline text-white border-white/30 hover:border-white text-base px-8 py-3.5">
              Create Account
            </Link>
          </div>
        </div>
      </section>

      {/* FAQ & Support Section */}
      <section className="section">
        <div className="container-x grid gap-12 lg:grid-cols-3">
          <div>
            <span className="text-xs font-bold uppercase tracking-wider text-accent mb-2 block">Help Desk</span>
            <h2 className="heading">Got Questions?</h2>
            <p className="mt-3 text-neutral-600 leading-relaxed">
              Find answers to rental requirements, deposit refunds, and cancellation rules. For more details, explore our full{' '}
              <Link to="/faq" className="font-bold text-accent underline">
                FAQ section
              </Link>.
            </p>
          </div>
          <div className="lg:col-span-2">
            <Faq />
          </div>
        </div>
      </section>

      {/* Newsletter Section */}
      <section className="bg-gradient-to-r from-accent to-accent-dark text-white">
        <div className="container-x flex flex-col justify-between gap-8 py-16 lg:flex-row lg:items-center">
          <div>
            <h2 className="text-3xl font-extrabold sm:text-4xl tracking-tight">Stay in the fast lane.</h2>
            <p className="mt-2 text-white/85 text-base">Get monthly coupon discounts and new fleet alerts delivered to your inbox.</p>
          </div>
          <Newsletter />
        </div>
      </section>
    </>
  );
}
