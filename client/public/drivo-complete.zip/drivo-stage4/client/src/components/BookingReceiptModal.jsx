import { useEffect, useState, useRef } from 'react';
import { X, Printer, Download, CheckCircle2, AlertCircle, FileText } from 'lucide-react';
import { apiRequest } from '../services/api.js';
import { formatINR } from '../utils/pricing.js';

export default function BookingReceiptModal({ bookingRef, onClose }) {
  const [receipt, setReceipt] = useState(null);
  const [loading, setLoading] = useState(true);
  const printRef = useRef(null);

  useEffect(() => {
    if (!bookingRef) return;
    setLoading(true);
    apiRequest(`/bookings/${bookingRef}/receipt`)
      .then((res) => setReceipt(res.receipt))
      .catch(() => setReceipt(null))
      .finally(() => setLoading(false));
  }, [bookingRef]);

  const handlePrint = () => {
    window.print();
  };

  if (!bookingRef) return null;

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/60 p-4 backdrop-blur-sm print:p-0 print:bg-white">
      <div className="relative max-h-[90vh] w-full max-w-2xl overflow-y-auto rounded-3xl bg-white p-6 shadow-2xl sm:p-8 print:max-h-none print:shadow-none print:p-6 print:rounded-none">
        {/* Header Actions - hidden in print */}
        <div className="flex items-center justify-between border-b border-neutral-100 pb-4 print:hidden">
          <div className="flex items-center gap-2">
            <span className="grid h-9 w-9 place-items-center rounded-xl bg-ink text-white">
              <FileText size={18} />
            </span>
            <h2 className="text-lg font-extrabold text-ink">Booking Receipt & Tax Invoice</h2>
          </div>
          <div className="flex items-center gap-2">
            <button
              onClick={handlePrint}
              className="btn-outline flex items-center gap-1.5 px-3 py-1.5 text-xs"
              title="Print or Save as PDF"
            >
              <Printer size={15} /> Print / Save PDF
            </button>
            <button
              onClick={onClose}
              className="grid h-8 w-8 place-items-center rounded-full text-neutral-400 hover:bg-neutral-100 hover:text-ink"
            >
              <X size={18} />
            </button>
          </div>
        </div>

        {loading ? (
          <div className="py-20 text-center">
            <div className="mx-auto h-8 w-8 animate-spin rounded-full border-2 border-ink border-t-transparent" />
            <p className="mt-3 text-sm text-neutral-500">Preparing invoice...</p>
          </div>
        ) : !receipt ? (
          <div className="py-12 text-center">
            <AlertCircle size={36} className="mx-auto text-amber-500" />
            <p className="mt-2 text-sm text-neutral-600">Could not retrieve invoice for this booking.</p>
          </div>
        ) : (
          <div ref={printRef} className="pt-4 print:pt-0">
            {/* Invoice Top Section */}
            <div className="flex flex-col sm:flex-row sm:items-start sm:justify-between gap-4 border-b border-neutral-200 pb-6">
              <div>
                <h1 className="text-2xl font-black tracking-tight text-ink">DRIVO CAR RENTAL</h1>
                <p className="text-xs text-neutral-500 mt-0.5">{receipt.company.address}</p>
                <p className="text-xs text-neutral-500">GSTIN: {receipt.company.taxId} · {receipt.company.supportEmail}</p>
              </div>
              <div className="sm:text-right">
                <span className="inline-block rounded-lg bg-neutral-100 px-3 py-1 font-mono text-xs font-bold text-ink">
                  {receipt.invoiceNumber}
                </span>
                <p className="mt-1 text-xs text-neutral-500">Booking Ref: <strong>{receipt.bookingRef}</strong></p>
                <p className="text-xs text-neutral-500">Date: {receipt.invoiceDate}</p>
              </div>
            </div>

            {/* Status Strip */}
            <div className="my-5 flex flex-wrap items-center justify-between gap-2 rounded-2xl bg-neutral-50 p-3 text-xs">
              <div>
                <span className="text-neutral-500">Booking Status: </span>
                <strong className={`font-bold ${receipt.status === 'Cancelled' ? 'text-red-600' : 'text-green-700'}`}>
                  {receipt.status}
                </strong>
              </div>
              <div>
                <span className="text-neutral-500">Payment Status: </span>
                <strong className={`font-bold ${receipt.paymentStatus === 'Paid' ? 'text-green-700' : receipt.paymentStatus === 'Refunded' ? 'text-neutral-600' : 'text-amber-700'}`}>
                  {receipt.paymentStatus.toUpperCase()}
                </strong>
              </div>
              <div>
                <span className="text-neutral-500">Method: </span>
                <span className="font-medium text-ink">{receipt.paymentMethod}</span>
              </div>
            </div>

            {/* Customer & Vehicle Grid */}
            <div className="grid grid-cols-1 sm:grid-cols-2 gap-6 border-b border-neutral-200 pb-6 text-xs">
              <div>
                <h3 className="font-bold uppercase tracking-wider text-neutral-400 mb-2">Billed To</h3>
                <p className="font-extrabold text-sm text-ink">{receipt.customer.name}</p>
                <p className="text-neutral-600 mt-0.5">{receipt.customer.email}</p>
                <p className="text-neutral-600">{receipt.customer.phone}</p>
                {receipt.customer.license && (
                  <p className="text-neutral-500 mt-1">Driving Licence: <span className="font-mono">{receipt.customer.license}</span></p>
                )}
              </div>
              <div>
                <h3 className="font-bold uppercase tracking-wider text-neutral-400 mb-2">Vehicle Reserved</h3>
                <p className="font-extrabold text-sm text-ink">{receipt.vehicle.name}</p>
                <p className="text-neutral-600 mt-0.5">{receipt.vehicle.category} · {receipt.vehicle.transmission} · {receipt.vehicle.fuel}</p>
                <p className="text-neutral-600">Daily Rate: {formatINR(receipt.vehicle.ratePerDay)} / day</p>
              </div>
            </div>

            {/* Trip Schedule */}
            <div className="py-4 border-b border-neutral-200 text-xs">
              <h3 className="font-bold uppercase tracking-wider text-neutral-400 mb-2">Rental Schedule</h3>
              <div className="grid grid-cols-1 sm:grid-cols-3 gap-2">
                <div>
                  <span className="text-neutral-500 block">Pickup ({receipt.schedule.pickupLocation}):</span>
                  <span className="font-semibold text-ink">{new Date(receipt.schedule.startTime).toLocaleString('en-IN', { dateStyle: 'medium', timeStyle: 'short' })}</span>
                </div>
                <div>
                  <span className="text-neutral-500 block">Return ({receipt.schedule.dropoffLocation}):</span>
                  <span className="font-semibold text-ink">{new Date(receipt.schedule.endTime).toLocaleString('en-IN', { dateStyle: 'medium', timeStyle: 'short' })}</span>
                </div>
                <div>
                  <span className="text-neutral-500 block">Duration:</span>
                  <span className="font-bold text-ink">{receipt.schedule.days} day(s)</span>
                </div>
              </div>
            </div>

            {/* Itemized Charges */}
            <div className="pt-4 text-xs">
              <h3 className="font-bold uppercase tracking-wider text-neutral-400 mb-3">Itemized Charges</h3>
              <div className="space-y-2">
                <div className="flex justify-between text-neutral-700">
                  <span>Base Vehicle Rental ({receipt.schedule.days} days)</span>
                  <span className="font-mono">{formatINR(receipt.charges.baseRental)}</span>
                </div>
                {receipt.charges.extras > 0 && (
                  <div className="flex justify-between text-neutral-700">
                    <span>Optional Extras & Cover</span>
                    <span className="font-mono">{formatINR(receipt.charges.extras)}</span>
                  </div>
                )}
                {receipt.charges.discount > 0 && (
                  <div className="flex justify-between text-green-700 font-semibold">
                    <span>Coupon Discount Applied</span>
                    <span className="font-mono">-{formatINR(receipt.charges.discount)}</span>
                  </div>
                )}
                <div className="flex justify-between text-neutral-700">
                  <span>Goods & Services Tax (GST 18%)</span>
                  <span className="font-mono">{formatINR(receipt.charges.gst)}</span>
                </div>
                <div className="flex justify-between text-neutral-500">
                  <span>Refundable Security Deposit (Held on card)</span>
                  <span className="font-mono">{formatINR(receipt.charges.securityDeposit)}</span>
                </div>
                <div className="flex justify-between border-t border-neutral-300 pt-3 text-base font-extrabold text-ink">
                  <span>Total Amount</span>
                  <span className="font-mono text-lg">{formatINR(receipt.charges.totalAmount)}</span>
                </div>
              </div>
            </div>

            {/* Receipt Footer */}
            <div className="mt-8 border-t border-neutral-100 pt-4 text-[11px] text-neutral-400 text-center">
              <p>Thank you for choosing Drivo. Valid driving licence and original ID verification mandatory at car handover.</p>
              <p className="mt-1">Computer-generated receipt · No signature required.</p>
            </div>
          </div>
        )}
      </div>
    </div>
  );
}
