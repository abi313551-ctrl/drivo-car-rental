import { useState, useMemo } from 'react';
import { useNavigate } from 'react-router-dom';
import { Search, MapPin, Calendar, Car } from 'lucide-react';
import toast from 'react-hot-toast';
import { locations as defaultLocations, categories as defaultCategories } from '../data/homeContent.js';
import { validateSearch } from '../utils/validation.js';
import { toLocalInput } from '../utils/pricing.js';
import { useCars } from '../context/CarContext.jsx';

export default function SearchBar() {
  const navigate = useNavigate();
  const { cars } = useCars();
  const now = toLocalInput(new Date());
  const [form, setForm] = useState({ pickup: '', dropoff: '', start: '', end: '', category: '' });
  const [errors, setErrors] = useState({});

  const availableLocations = useMemo(() => {
    const fromCars = cars.map((c) => c.location).filter(Boolean);
    return [...new Set([...fromCars, ...defaultLocations])];
  }, [cars]);

  const set = (k) => (e) => {
    const value = e.target.value;
    setForm((f) => {
      const next = { ...f, [k]: value };
      // If user sets pickup and dropoff is empty, auto-set dropoff
      if (k === 'pickup' && !f.dropoff) {
        next.dropoff = value;
      }
      return next;
    });
    setErrors((er) => ({ ...er, [k]: undefined, ...(k === 'start' ? { end: undefined } : {}) }));
  };

  const onSubmit = (ev) => {
    ev.preventDefault();
    const e = validateSearch(form);
    setErrors(e);
    if (Object.keys(e).length) {
      toast.error('Please pick valid locations and dates');
      return;
    }
    const cleanParams = Object.fromEntries(Object.entries(form).filter(([, v]) => v));
    navigate(`/cars?${new URLSearchParams(cleanParams).toString()}`);
  };

  return (
    <form
      onSubmit={onSubmit}
      noValidate
      className="glass-card grid gap-4 p-5 sm:p-7 text-ink lg:grid-cols-5 lg:items-end shadow-2xl border-white/60"
    >
      <div>
        <label htmlFor="sb-pickup" className="mb-1.5 flex items-center gap-1.5 text-xs font-bold uppercase tracking-wider text-neutral-600">
          <MapPin size={14} className="text-accent" /> Pickup Location
        </label>
        <select
          id="sb-pickup"
          className="field font-semibold text-neutral-800"
          value={form.pickup}
          onChange={set('pickup')}
          aria-invalid={!!errors.pickup}
        >
          <option value="">Select city</option>
          {availableLocations.map((l) => (
            <option key={l} value={l}>{l}</option>
          ))}
        </select>
        {errors.pickup && <p className="field-error">{errors.pickup}</p>}
      </div>

      <div>
        <label htmlFor="sb-category" className="mb-1.5 flex items-center gap-1.5 text-xs font-bold uppercase tracking-wider text-neutral-600">
          <Car size={14} className="text-accent" /> Vehicle Category
        </label>
        <select
          id="sb-category"
          className="field font-semibold text-neutral-800"
          value={form.category}
          onChange={set('category')}
        >
          <option value="">All Categories</option>
          {defaultCategories.map((c) => (
            <option key={c.name} value={c.name}>{c.name}</option>
          ))}
        </select>
      </div>

      <div>
        <label htmlFor="sb-start" className="mb-1.5 flex items-center gap-1.5 text-xs font-bold uppercase tracking-wider text-neutral-600">
          <Calendar size={14} className="text-accent" /> Pickup Date & Time
        </label>
        <input
          id="sb-start"
          type="datetime-local"
          className="field font-medium text-neutral-800"
          min={now}
          value={form.start}
          onChange={set('start')}
          aria-invalid={!!errors.start}
        />
        {errors.start && <p className="field-error">{errors.start}</p>}
      </div>

      <div>
        <label htmlFor="sb-end" className="mb-1.5 flex items-center gap-1.5 text-xs font-bold uppercase tracking-wider text-neutral-600">
          <Calendar size={14} className="text-accent" /> Return Date & Time
        </label>
        <input
          id="sb-end"
          type="datetime-local"
          className="field font-medium text-neutral-800"
          min={form.start || now}
          value={form.end}
          onChange={set('end')}
          aria-invalid={!!errors.end}
        />
        {errors.end && <p className="field-error">{errors.end}</p>}
      </div>

      <div>
        <button
          type="submit"
          className="btn-primary w-full py-3.5 text-base font-bold flex items-center justify-center gap-2 shadow-xl hover:shadow-accent/50"
        >
          <Search size={18} /> Find Your Ride
        </button>
      </div>
    </form>
  );
}
